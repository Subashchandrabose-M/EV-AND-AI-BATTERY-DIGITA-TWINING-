import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

const PROJECT_SYSTEM_PROMPT = `You are the Battery AI Assistant for the college capstone project "EV Battery Digital Twin with Self-Healing Charging AI" by Arjun College Of Technology.
Team details:
- Team Leader: Subashchandrabose M
- Members: Rajaram A, Arun S, Velmurugan P
- Mentor: Kailas
- Institution: Arjun College Of Technology

Core Architecture (Sense -> Learn -> Heal):
- Sense: ESP32 microcontroller reads 3S Li-ion pack voltage, current (INA219), and cell temperatures (3x DS18B20) and streams telemetry via MQTT / Firebase.
- Learn: LSTM neural network trained on NASA & CALCE battery aging datasets forecasts State of Health (SoH) and Remaining Useful Life (RUL).
- Heal: Reinforcement Learning (RL) agent dynamically adjusts charging current and voltage taper in real time via a CC/CV buck converter + relay/MOSFET to minimize heat and slow capacity degradation.
- Prototype cost: approx Rs 3,200 - 6,500 (ESP32 Rs 400-600, INA219 Rs 150-350, 3x DS18B20 Rs 300-900, Li-ion cells + 3S BMS + holders Rs 1,500-3,000, charger control Rs 300-600, wires/enclosure Rs 500-1,000).
- Value model: Extending a Rs 5,00,000 EV pack lifespan by 5%-20% saves Rs 25,000-Rs 1,00,000 (assumptions, pending prototype validation).

Keep answers concise (2-4 sentences), technically accurate, plain text (no markdown asterisks or bold syntax), and helpful for a capstone demo audience.`;

function getConfiguredGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function generateWithRetry(ai: GoogleGenAI, question: string, attempts = 2) {
  let lastError: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: question,
        config: {
          systemInstruction: PROJECT_SYSTEM_PROMPT,
        },
      });
    } catch (error) {
      lastError = error;
      if (i < attempts - 1) {
        await new Promise((resolve) => setTimeout(resolve, 400 * (i + 1)));
      }
    }
  }
  throw lastError;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.post('/api/chat', async (req, res) => {
    const question = typeof req.body?.question === 'string' ? req.body.question.trim() : '';
    if (!question) {
      res.status(400).json({ error: 'Question is required.' });
      return;
    }

    const ai = getConfiguredGeminiClient();
    if (!ai) {
      res.json({ available: false });
      return;
    }

    try {
      const response = await generateWithRetry(ai, question);
      res.json({
        available: true,
        source: 'gemini',
        reply: response.text ?? 'No response generated.',
      });
    } catch (error) {
      console.error('Gemini API error:', error);
      res.status(502).json({
        available: true,
        error: 'Unable to reach Gemini API right now. Please try again.',
      });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EV Battery Digital Twin server listening on http://localhost:${PORT}`);
  });
}

startServer();
