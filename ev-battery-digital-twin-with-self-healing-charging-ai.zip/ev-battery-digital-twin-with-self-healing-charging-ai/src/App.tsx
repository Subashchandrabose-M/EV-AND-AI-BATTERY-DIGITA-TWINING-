import { useState } from 'react';
import { MotionConfig } from 'framer-motion';
import { Navbar, type CockpitView } from './components/Navbar';
import { LiveTwinDashboard } from './components/LiveTwinDashboard';
import { FastVsAiSimulator } from './components/FastVsAiSimulator';
import { AiAndArchitectureView } from './components/AiAndArchitectureView';
import { SecondLifeAndRoiView } from './components/SecondLifeAndRoiView';
import { BatteryAssistant } from './components/BatteryAssistant';
import { useBatterySimulation } from './hooks/useBatterySimulation';
import { useDualChargeSim } from './hooks/useDualChargeSim';

export default function App() {
  const [activeView, setActiveView] = useState<CockpitView>('twin');
  const [heatmapMode, setHeatmapMode] = useState(false);

  const batterySim = useBatterySimulation();
  const dualChargeSim = useDualChargeSim();

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen bg-[#05080F] bg-telemetry-grid text-[#F1F5F9] flex flex-col overflow-x-hidden">
        <Navbar
          activeView={activeView}
          onSelectView={setActiveView}
          isStreaming={batterySim.isStreaming}
        />

        <main className="flex-1">
          {activeView === 'twin' && (
            <LiveTwinDashboard
              sim={batterySim}
              heatmapMode={heatmapMode}
              onToggleHeatmap={() => setHeatmapMode((v) => !v)}
            />
          )}

          {activeView === 'simulator' && (
            <FastVsAiSimulator sim={dualChargeSim} />
          )}

          {activeView === 'ai-arch' && <AiAndArchitectureView />}

          {activeView === 'second-life' && <SecondLifeAndRoiView />}
        </main>

        <footer className="border-t border-slate-800/80 pt-5 pb-20 sm:pb-8 px-4 text-center text-xs text-slate-500 font-mono">
          EV Battery Digital Twin · Sense → Learn → Heal · 3S3P Li-ion Pack + Simulated NASA/CALCE LSTM & RL Controller
        </footer>

        <BatteryAssistant />
      </div>
    </MotionConfig>
  );
}
