import { useCallback, useEffect, useRef, useState } from 'react';
import {
  BatteryCellState,
  createInitial3SPack,
  stepPackTelemetry,
  TelemetryPoint,
  TEMP_WARNING_THRESHOLD_C,
} from '../utils/batteryPhysics';

export interface BatterySimulationState {
  cells: BatteryCellState[];
  history: TelemetryPoint[];
  packVoltage: number;
  effectiveCurrent: number;
  avgTemp: number;
  maxTemp: number;
  packSoc: number;
  packSoh: number;
  rulCycles: number;
  rlActionNote: string;
  mode: 'charging' | 'discharging';
  targetCurrentAmps: number;
  ambientTempC: number;
  autoHeal: boolean;
  thermalBoostActive: boolean;
  isStreaming: boolean;
  thermalAlert: {
    active: boolean;
    message: string;
    peakTemp: number;
  } | null;
}

function buildSeedHistory(initialCells: BatteryCellState[], ambientTempC = 27.0): TelemetryPoint[] {
  const pts: TelemetryPoint[] = [];
  let working = initialCells;
  for (let i = -14; i <= 0; i++) {
    const res = stepPackTelemetry(working, {
      mode: 'charging',
      targetCurrentAmps: 10.0,
      autoHeal: true,
      ambientTempC,
      thermalBoostActive: false,
      dtSeconds: 1,
    });
    working = res.nextCells;
    pts.push({
      timeLabel: `${i === 0 ? 'Now' : `${i}s`}`,
      tick: i + 14,
      packVoltage: res.packVoltage,
      current: res.effectiveCurrent,
      avgTemp: res.avgTemp,
      maxTemp: res.maxTemp,
      s1Temp: res.s1Temp,
      s2Temp: res.s2Temp,
      s3Temp: res.s3Temp,
      soc: res.packSoc,
    });
  }
  return pts;
}

export function useBatterySimulation() {
  const initialCellsRef = useRef<BatteryCellState[]>(createInitial3SPack(64, 94.2));
  const [cells, setCells] = useState<BatteryCellState[]>(initialCellsRef.current);
  const [history, setHistory] = useState<TelemetryPoint[]>(() =>
    buildSeedHistory(initialCellsRef.current)
  );
  const [packVoltage, setPackVoltage] = useState(11.42);
  const [effectiveCurrent, setEffectiveCurrent] = useState(10.0);
  const [avgTemp, setAvgTemp] = useState(29.8);
  const [maxTemp, setMaxTemp] = useState(31.2);
  const [packSoc, setPackSoc] = useState(64.2);
  const [packSoh, setPackSoh] = useState(94.1);
  const [rulCycles, setRulCycles] = useState(818);
  const [rlActionNote, setRlActionNote] = useState('RL Optimal Charge');

  const [mode, setMode] = useState<'charging' | 'discharging'>('charging');
  const [targetCurrentAmps, setTargetCurrentAmps] = useState(10.0);
  const [ambientTempC, setAmbientTempC] = useState(27.0);
  const [autoHeal, setAutoHeal] = useState(true);
  const [thermalBoostActive, setThermalBoostActive] = useState(false);
  const [isStreaming, setIsStreaming] = useState(true);
  const [thermalAlert, setThermalAlert] = useState<BatterySimulationState['thermalAlert']>(null);

  const tickRef = useRef(15);
  const alertDismissedAtRef = useRef<number>(0);

  const optionsRef = useRef({
    mode,
    targetCurrentAmps,
    ambientTempC,
    autoHeal,
    thermalBoostActive,
  });
  optionsRef.current = { mode, targetCurrentAmps, ambientTempC, autoHeal, thermalBoostActive };

  useEffect(() => {
    if (!isStreaming) return;

    const timer = window.setInterval(() => {
      setCells((prevCells) => {
        const opts = optionsRef.current;
        const step = stepPackTelemetry(prevCells, {
          mode: opts.mode,
          targetCurrentAmps: opts.targetCurrentAmps,
          autoHeal: opts.autoHeal,
          ambientTempC: opts.ambientTempC,
          thermalBoostActive: opts.thermalBoostActive,
          dtSeconds: 1,
        });

        tickRef.current += 1;
        const nowTick = tickRef.current;

        setPackVoltage(step.packVoltage);
        setEffectiveCurrent(step.effectiveCurrent);
        setAvgTemp(step.avgTemp);
        setMaxTemp(step.maxTemp);
        setPackSoc(step.packSoc);
        setPackSoh(step.packSoh);
        setRulCycles(step.rulCycles);
        setRlActionNote(step.rlActionNote);

        if (step.maxTemp > TEMP_WARNING_THRESHOLD_C) {
          if (Date.now() - alertDismissedAtRef.current > 6000) {
            setThermalAlert({
              active: true,
              peakTemp: step.maxTemp,
              message: opts.autoHeal
                ? `Thermal threshold (> ${TEMP_WARNING_THRESHOLD_C}°C) reached at ${step.maxTemp.toFixed(1)}°C — RL agent throttled current to ${step.effectiveCurrent.toFixed(1)} A.`
                : `Critical thermal alert: Cell peak at ${step.maxTemp.toFixed(1)}°C with AI Healing OFF!`,
            });
          }
        } else {
          setThermalAlert((prev) => (prev ? null : prev));
        }

        const nowLabel = new Date().toLocaleTimeString('en-US', {
          hour12: false,
          minute: '2-digit',
          second: '2-digit',
        });

        setHistory((prevHist) => {
          const next = [
            ...prevHist,
            {
              timeLabel: nowLabel,
              tick: nowTick,
              packVoltage: step.packVoltage,
              current: step.effectiveCurrent,
              avgTemp: step.avgTemp,
              maxTemp: step.maxTemp,
              s1Temp: step.s1Temp,
              s2Temp: step.s2Temp,
              s3Temp: step.s3Temp,
              soc: step.packSoc,
            },
          ];
          return next.slice(-30);
        });

        return step.nextCells;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [isStreaming]);

  const dismissAlert = useCallback(() => {
    alertDismissedAtRef.current = Date.now();
    setThermalAlert(null);
  }, []);

  const resetPack = useCallback(() => {
    const fresh = createInitial3SPack(64, 94.2);
    setCells(fresh);
    setAmbientTempC(27.0);
    setTargetCurrentAmps(10.0);
    setMode('charging');
    setAutoHeal(true);
    setHistory(buildSeedHistory(fresh, 27.0));
    setPackVoltage(11.42);
    setEffectiveCurrent(10.0);
    setAvgTemp(29.8);
    setMaxTemp(31.2);
    setPackSoc(64.2);
    setPackSoh(94.1);
    setRulCycles(818);
    setRlActionNote('RL Optimal Charge');
    setThermalBoostActive(false);
    setThermalAlert(null);
  }, []);

  return {
    cells,
    history,
    packVoltage,
    effectiveCurrent,
    avgTemp,
    maxTemp,
    packSoc,
    packSoh,
    rulCycles,
    rlActionNote,
    mode,
    setMode,
    targetCurrentAmps,
    setTargetCurrentAmps,
    ambientTempC,
    setAmbientTempC,
    autoHeal,
    setAutoHeal,
    thermalBoostActive,
    setThermalBoostActive,
    isStreaming,
    setIsStreaming,
    thermalAlert,
    dismissAlert,
    resetPack,
  };
}
