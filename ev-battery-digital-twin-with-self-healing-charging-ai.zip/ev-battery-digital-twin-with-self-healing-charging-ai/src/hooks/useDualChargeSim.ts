import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  createInitialDualChargeState,
  DualChargeSnapshot,
  stepDualChargeSimulation,
  summarizeDualCharge,
} from '../utils/batteryPhysics';

export function useDualChargeSim() {
  const [history, setHistory] = useState<DualChargeSnapshot[]>(() => [
    createInitialDualChargeState(),
  ]);
  const [isRunning, setIsRunning] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(2);

  const latest = history[history.length - 1];
  const isComplete = latest.fastSoc >= 95 && latest.aiSoc >= 95;

  useEffect(() => {
    if (!isRunning || isComplete) {
      if (isComplete && isRunning) {
        setIsRunning(false);
      }
      return;
    }

    const intervalMs = Math.max(80, Math.round(700 / speedMultiplier));
    const timer = window.setInterval(() => {
      setHistory((prev) => {
        const last = prev[prev.length - 1];
        if (last.fastSoc >= 95 && last.aiSoc >= 95) {
          return prev;
        }
        const next = stepDualChargeSimulation(last);
        return [...prev, next];
      });
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [isRunning, isComplete, speedMultiplier]);

  const start = useCallback(() => {
    if (isComplete) {
      setHistory([createInitialDualChargeState()]);
    }
    setIsRunning(true);
  }, [isComplete]);

  const pause = useCallback(() => {
    setIsRunning(false);
  }, []);

  const reset = useCallback(() => {
    setIsRunning(false);
    setHistory([createInitialDualChargeState()]);
  }, []);

  const summary = useMemo(() => summarizeDualCharge(history), [history]);

  return {
    history,
    latest,
    summary,
    isRunning,
    isComplete,
    speedMultiplier,
    setSpeedMultiplier,
    start,
    pause,
    reset,
  };
}
