export interface LstmTrajectoryPoint {
  cycle: number;
  actualSoh: number;
  predictedSoh: number;
  upperBound: number;
  lowerBound: number;
  rulCycles: number;
}

export interface RlEpisodePoint {
  episode: number;
  reward: number;
  avgPeakTemp: number;
}

export interface RlStepSample {
  stepName: string;
  state: string;
  action: string;
  reward: string;
  rationale: string;
}

/**
 * Generates NASA B0005 / CALCE CS2-style capacity fade trajectories (0 to 1000 cycles).
 * Explicitly labeled in the UI as an in-browser simulation modeled on NASA/CALCE aging behavior.
 */
export function generateLstmCurveData(): LstmTrajectoryPoint[] {
  const points: LstmTrajectoryPoint[] = [];
  for (let cycle = 0; cycle <= 1000; cycle += 50) {
    // Realistic Li-ion degradation: gradual linear SEI growth + non-linear knee after cycle 650
    const linearFade = (cycle / 1000) * 11.5;
    const kneeFade = cycle > 600 ? Math.pow((cycle - 600) / 400, 1.85) * 9.8 : 0;
    const wave = Math.sin(cycle * 0.045) * 0.35;
    const actualSoh = Number(Math.max(76.5, 100 - linearFade - kneeFade + wave).toFixed(2));
    const predictionBias = Math.cos(cycle * 0.03) * 0.28;
    const predictedSoh = Number(Math.max(76.5, 100 - linearFade - kneeFade + predictionBias).toFixed(2));
    const uncertainty = 0.4 + (cycle / 1000) * 0.9;
    const rulCycles = Math.max(0, Math.round((predictedSoh - 80) * 46));

    points.push({
      cycle,
      actualSoh,
      predictedSoh,
      upperBound: Number((predictedSoh + uncertainty).toFixed(2)),
      lowerBound: Number((predictedSoh - uncertainty).toFixed(2)),
      rulCycles,
    });
  }
  return points;
}

export function generateRlRewardCurve(): RlEpisodePoint[] {
  const points: RlEpisodePoint[] = [];
  for (let ep = 1; ep <= 40; ep += 3) {
    const progress = 1 - Math.exp(-ep / 11);
    const noise = Math.sin(ep * 1.4) * (1 - progress) * 4.5;
    const reward = Number((-28 + 114 * progress + noise).toFixed(1));
    const avgPeakTemp = Number((47.5 - 10.8 * progress + noise * 0.12).toFixed(1));
    points.push({
      episode: ep,
      reward,
      avgPeakTemp,
    });
  }
  return points;
}

export const RL_LOOP_SAMPLES: RlStepSample[] = [
  {
    stepName: 'Cool Start Window',
    state: 'SoC 22% · T 28.4°C · SoH 94.2%',
    action: 'Apply 1.9C Fast Ramp (19.0 A)',
    reward: '+9.4',
    rationale: 'Cell impedance is low and thermal headroom is high; charge rapidly without stress.',
  },
  {
    stepName: 'Mid-Charge Thermal Rise',
    state: 'SoC 58% · T 36.8°C · dT/dt +0.4°C/m',
    action: 'Throttle to 1.35C (13.5 A)',
    reward: '+11.8',
    rationale: 'Proactively curtails I²R Joule heating before crossing the 40°C SEI acceleration knee.',
  },
  {
    stepName: 'High-SoC CV Taper',
    state: 'SoC 86% · T 35.1°C · V 4.16 V',
    action: 'Soft Taper 0.6C + Micro-Rest',
    reward: '+12.6',
    rationale: 'Prevents lithium plating at high anode potential while finishing top-off smoothly.',
  },
];
