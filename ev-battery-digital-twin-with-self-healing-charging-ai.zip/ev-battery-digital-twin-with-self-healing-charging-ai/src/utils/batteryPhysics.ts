export type CellThermalStatus = 'Nominal' | 'Elevated' | 'Thermal Alert';

export interface BatteryCellState {
  id: string;
  label: string;
  bank: 'S1' | 'S2' | 'S3';
  slotIndex: number;
  voltage: number;
  temperature: number;
  soc: number;
  soh: number;
  internalResistanceMohm: number;
  status: CellThermalStatus;
  /** Slight physical variance multiplier from manufacturing & inner-pack thermal coupling */
  resistanceFactor: number;
  coolingFactor: number;
}

export interface TelemetryPoint {
  timeLabel: string;
  tick: number;
  packVoltage: number;
  current: number;
  avgTemp: number;
  maxTemp: number;
  s1Temp: number;
  s2Temp: number;
  s3Temp: number;
  soc: number;
}

export interface DualChargeSnapshot {
  minute: number;
  fastSoc: number;
  aiSoc: number;
  fastTemp: number;
  aiTemp: number;
  fastCurrent: number;
  aiCurrent: number;
  fastVoltage: number;
  aiVoltage: number;
  /** Cumulative micro-degradation in % SoH lost during this charge session (scaled x1000 for visibility in m%) */
  fastHealthLossMpct: number;
  aiHealthLossMpct: number;
  fastSoh: number;
  aiSoh: number;
  aiPolicyAction: string;
}

export interface DualChargeSummary {
  fastPeakTemp: number;
  aiPeakTemp: number;
  coolerPeakTempPct: number;
  tempReductionPct: number;
  fastHealthLossMpct: number;
  aiHealthLossMpct: number;
  degradationReductionPct: number;
  extendedLifespanPct: number;
  fastDurationMin: number;
  aiDurationMin: number;
  estimatedExtraCycles: number;
}

export interface SecondLifeGrade {
  grade: 'A' | 'B' | 'C';
  title: string;
  useCase: string;
  valueRetentionPct: number;
  accentHex: string;
}

export const PACK_NOMINAL_AH = 9.0; // 3S3P pack using 3.0 Ah 18650/21700 cells
export const TEMP_WARNING_THRESHOLD_C = 40.0;
export const TEMP_CRITICAL_THRESHOLD_C = 45.0;

/**
 * Realistic Li-ion (NMC) Open-Circuit Voltage vs State of Charge curve (0 - 100%).
 * Returns single-cell OCV in Volts [3.05V .. 4.19V].
 */
export function computeCellOcv(socPct: number): number {
  const s = Math.max(0, Math.min(100, socPct)) / 100;
  const base = 3.05 + 0.82 * s + 0.32 * Math.pow(s, 3);
  const kneeLow = -0.14 * Math.exp(-18 * s);
  const kneeHigh = 0.08 * Math.exp(-12 * (1 - s));
  return Number(Math.max(3.0, Math.min(4.2, base + kneeLow + kneeHigh)).toFixed(4));
}

/**
 * Cell internal resistance in Ohms as a function of SoH (%) and Temperature (°C).
 */
export function computeInternalResistanceOhm(sohPct: number, tempC: number, factor = 1.0): number {
  const sohPenalty = 1 + Math.max(0, (100 - sohPct) / 20) * 0.55;
  const thermalMobility = 1 + Math.max(0, (25 - tempC) * 0.018);
  const baseOhm = 0.021; // 21 mOhm NMC cylindrical cell
  return baseOhm * sohPenalty * thermalMobility * factor;
}

export function getThermalStatus(tempC: number): CellThermalStatus {
  if (tempC > TEMP_WARNING_THRESHOLD_C) return 'Thermal Alert';
  if (tempC >= 35.5) return 'Elevated';
  return 'Nominal';
}

/**
 * Maps temperature (°C) to Green (#22E58B) -> Amber (#F59E0B) -> Crimson (#EF4444).
 */
export function computeThermalColorHex(tempC: number): string {
  const t = Math.max(24, Math.min(46, tempC));
  if (t <= 35) {
    // 24 -> 35: #22E58B (34,229,139) to #F59E0B (245,158,11)
    const ratio = (t - 24) / 11;
    const r = Math.round(34 + (245 - 34) * ratio);
    const g = Math.round(229 + (158 - 229) * ratio);
    const b = Math.round(139 + (11 - 139) * ratio);
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  }
  // 35 -> 46: #F59E0B (245,158,11) to #EF4444 (239,68,68)
  const ratio = (t - 35) / 11;
  const r = Math.round(245 + (239 - 245) * ratio);
  const g = Math.round(158 + (68 - 158) * ratio);
  const b = Math.round(11 + (68 - 11) * ratio);
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

/**
 * Creates initial 3S3P (9 cells across 3 series banks S1, S2, S3 x 3 parallel cells) battery pack.
 * Center cells naturally have lower coolingFactor to reflect real inner-pack thermal gradients.
 */
export function createInitial3SPack(initialSoc = 64, initialSoh = 94.2): BatteryCellState[] {
  const banks: Array<'S1' | 'S2' | 'S3'> = ['S1', 'S2', 'S3'];
  const cells: BatteryCellState[] = [];
  let idx = 0;

  for (let b = 0; b < banks.length; b++) {
    for (let p = 0; p < 3; p++) {
      const isCenterBank = b === 1;
      const isCenterParallel = p === 1;
      const resistanceFactor = 0.96 + ((idx * 7) % 9) * 0.014;
      const coolingFactor =
        isCenterBank && isCenterParallel ? 0.78 : isCenterBank || isCenterParallel ? 0.9 : 1.05;
      const baseTemp = 28.8 + (isCenterBank ? 1.5 : 0.2) + (isCenterParallel ? 1.1 : 0);
      const cellSoc = Math.max(5, Math.min(99, initialSoc + ((idx % 3) - 1) * 0.45));
      const cellSoh = Number((initialSoh - (isCenterBank ? 0.3 : 0) - (idx % 3) * 0.14).toFixed(2));
      const rOhm = computeInternalResistanceOhm(cellSoh, baseTemp, resistanceFactor);
      const voltage = computeCellOcv(cellSoc);

      cells.push({
        id: `${banks[b]}-C${p + 1}`,
        label: `${banks[b]} · Cell ${p + 1}`,
        bank: banks[b],
        slotIndex: idx,
        voltage,
        temperature: Number(baseTemp.toFixed(2)),
        soc: Number(cellSoc.toFixed(2)),
        soh: cellSoh,
        internalResistanceMohm: Number((rOhm * 1000).toFixed(1)),
        status: getThermalStatus(baseTemp),
        resistanceFactor,
        coolingFactor,
      });
      idx++;
    }
  }
  return cells;
}

/**
 * Arrhenius-accelerated NASA/CALCE-inspired per-step degradation increment (% SoH).
 * Accelerates sharply when temperature exceeds 38°C or C-rate is aggressive.
 */
export function computeCycleDegradationPct(
  currentAmps: number,
  tempC: number,
  capacityAh = PACK_NOMINAL_AH,
  dtSeconds = 1
): number {
  const cRate = Math.abs(currentAmps) / capacityAh;
  const baseArrhenius = Math.exp(Math.max(0, tempC - 28) * 0.075);
  const kneeAcceleration = tempC > 38 ? 1 + Math.pow((tempC - 38) / 4, 1.8) * 1.4 : 1;
  const currentStress = Math.pow(Math.max(0.15, cRate), 1.5);
  const hours = dtSeconds / 3600;
  return 0.0045 * currentStress * baseArrhenius * kneeAcceleration * hours;
}

/**
 * Advances live 3S3P pack telemetry by dtSeconds.
 * RL agent evaluates state [Voltage, Current, Temp, SoC] and throttles charging current when thermal/high-SoC risk rises.
 */
export function stepPackTelemetry(
  cells: BatteryCellState[],
  options: {
    mode: 'charging' | 'discharging';
    targetCurrentAmps: number;
    autoHeal: boolean;
    ambientTempC: number;
    thermalBoostActive: boolean;
    dtSeconds?: number;
  }
): {
  nextCells: BatteryCellState[];
  packVoltage: number;
  effectiveCurrent: number;
  avgTemp: number;
  maxTemp: number;
  s1Temp: number;
  s2Temp: number;
  s3Temp: number;
  packSoc: number;
  packSoh: number;
  rulCycles: number;
  rlActionNote: string;
} {
  const dt = options.dtSeconds ?? 1;
  const maxCurrentTemp = Math.max(...cells.map((c) => c.temperature));
  const avgCurrentSoc = cells.reduce((acc, c) => acc + c.soc, 0) / cells.length;

  let effectiveCurrent = options.targetCurrentAmps;
  let rlActionNote = 'Nominal CC Profile';

  if (options.mode === 'charging') {
    if (options.autoHeal) {
      if (maxCurrentTemp >= 40.0) {
        effectiveCurrent = Math.min(effectiveCurrent, 3.8);
        rlActionNote = 'RL Throttle (0.42C)';
      } else if (maxCurrentTemp >= 36.5) {
        effectiveCurrent = Math.min(effectiveCurrent, 6.2);
        rlActionNote = 'RL Taper (0.69C)';
      } else if (avgCurrentSoc > 82) {
        effectiveCurrent = Math.min(effectiveCurrent, 5.2);
        rlActionNote = 'RL Soft CV Taper';
      } else {
        rlActionNote = 'RL Optimal Charge';
      }
    } else {
      rlActionNote = 'Fixed CC (No RL Guard)';
    }
    if (avgCurrentSoc >= 99.5) {
      effectiveCurrent = 0.4;
      rlActionNote = 'Trickle Top-Off';
    }
  } else {
    effectiveCurrent = -Math.abs(options.targetCurrentAmps);
    rlActionNote = 'EV Drive Load';
  }

  // Per parallel cell current in 3P bank
  const cellCurrent = effectiveCurrent / 3;
  const nextCells = cells.map((cell) => {
    const rOhm = computeInternalResistanceOhm(cell.soh, cell.temperature, cell.resistanceFactor);
    const ocv = computeCellOcv(cell.soc);
    const vTerm = Math.max(2.9, Math.min(4.24, ocv + cellCurrent * rOhm));

    const deltaAh = (effectiveCurrent * dt) / 3600;
    const nextSoc = Math.max(5, Math.min(99.8, cell.soc + (deltaAh / PACK_NOMINAL_AH) * 100));

    // Calibrated I^2*R Joule heating + optional stress spike + convective ambient cooling
    const jouleWatts = Math.pow(cellCurrent, 2) * rOhm * 1.15;
    const spikeWatts = options.thermalBoostActive ? 1.28 * (2 - cell.coolingFactor) : 0;
    const coolingWatts = (cell.temperature - options.ambientTempC) * 0.068 * cell.coolingFactor;
    const nextTemp = Math.max(
      18,
      Math.min(54, cell.temperature + (jouleWatts + spikeWatts - coolingWatts) * dt * 0.9)
    );

    const fade = computeCycleDegradationPct(effectiveCurrent, nextTemp, PACK_NOMINAL_AH, dt);
    const nextSoh = Math.max(60, cell.soh - fade);

    return {
      ...cell,
      voltage: Number(vTerm.toFixed(3)),
      temperature: Number(nextTemp.toFixed(2)),
      soc: Number(nextSoc.toFixed(2)),
      soh: Number(nextSoh.toFixed(3)),
      internalResistanceMohm: Number((rOhm * 1000).toFixed(1)),
      status: getThermalStatus(nextTemp),
    };
  });

  const bankVoltageAvgs = (['S1', 'S2', 'S3'] as const).map((bank) => {
    const group = nextCells.filter((c) => c.bank === bank);
    return group.reduce((s, c) => s + c.voltage, 0) / group.length;
  });
  const bankTempMax = (bank: 'S1' | 'S2' | 'S3') => {
    const group = nextCells.filter((c) => c.bank === bank);
    return Number(Math.max(...group.map((c) => c.temperature)).toFixed(2));
  };

  const packVoltage = Number(bankVoltageAvgs.reduce((a, b) => a + b, 0).toFixed(2));
  const avgTemp = Number((nextCells.reduce((s, c) => s + c.temperature, 0) / nextCells.length).toFixed(2));
  const maxTemp = Number(Math.max(...nextCells.map((c) => c.temperature)).toFixed(2));
  const packSoc = Number((nextCells.reduce((s, c) => s + c.soc, 0) / nextCells.length).toFixed(1));
  const packSoh = Number((nextCells.reduce((s, c) => s + c.soh, 0) / nextCells.length).toFixed(2));

  const remainingHealthyPct = Math.max(0, packSoh - 80);
  const tempPenaltyFactor = avgTemp > 38 ? 0.8 : avgTemp > 33 ? 0.92 : 1.0;
  const rulCycles = Math.round(remainingHealthyPct * 58 * tempPenaltyFactor);

  return {
    nextCells,
    packVoltage,
    effectiveCurrent: Number(effectiveCurrent.toFixed(2)),
    avgTemp,
    maxTemp,
    s1Temp: bankTempMax('S1'),
    s2Temp: bankTempMax('S2'),
    s3Temp: bankTempMax('S3'),
    packSoc,
    packSoh,
    rulCycles,
    rlActionNote,
  };
}

/**
 * Dual-charge What-If simulator: Fixed CC/CV Fast Charger vs AI Self-Healing RL Agent.
 * Simulates 15% -> 95% SoC charge in 1-minute increments.
 */
export function createInitialDualChargeState(): DualChargeSnapshot {
  return {
    minute: 0,
    fastSoc: 15,
    aiSoc: 15,
    fastTemp: 28.0,
    aiTemp: 28.0,
    fastCurrent: 20.0,
    aiCurrent: 18.5,
    fastVoltage: 10.95,
    aiVoltage: 10.92,
    fastHealthLossMpct: 0,
    aiHealthLossMpct: 0,
    fastSoh: 95.0,
    aiSoh: 95.0,
    aiPolicyAction: 'Optimal Fast Ramp (2.05C)',
  };
}

export function stepDualChargeSimulation(prev: DualChargeSnapshot): DualChargeSnapshot {
  const ambient = 27.0;
  const minute = prev.minute + 1;

  // 1. Standard Fixed CC/CV Fast Charger
  let fastCurrent = 0;
  if (prev.fastSoc < 95) {
    if (prev.fastSoc < 80) {
      fastCurrent = 20.0; // Aggressive ~2.22C constant current
    } else {
      fastCurrent = Math.max(3.2, 20.0 * (1 - (prev.fastSoc - 80) / 18));
    }
  }

  const fastR = computeInternalResistanceOhm(prev.fastSoh, prev.fastTemp, 1.0);
  const fastJoule = Math.pow(fastCurrent, 2) * fastR * 0.185;
  const fastCooling = (prev.fastTemp - ambient) * 0.145;
  const fastTemp = Math.min(54.5, Math.max(ambient, prev.fastTemp + fastJoule - fastCooling));
  const fastSoc = Math.min(95, prev.fastSoc + (fastCurrent / PACK_NOMINAL_AH) * (100 / 60) * 1.15);
  const fastVoltage = Number((computeCellOcv(fastSoc) * 3 + fastCurrent * fastR * 0.4).toFixed(2));
  const fastFadeMpct =
    computeCycleDegradationPct(fastCurrent, fastTemp, PACK_NOMINAL_AH, 60) * 1000 * 3.8;
  const fastHealthLossMpct = prev.fastHealthLossMpct + fastFadeMpct;
  const fastSoh = Number((95.0 - fastHealthLossMpct / 1000).toFixed(4));

  // 2. AI Self-Healing RL Agent
  let aiCurrent = 0;
  let aiPolicyAction = 'Charge Complete · Cell Balanced';
  if (prev.aiSoc < 95) {
    if (prev.aiTemp >= 37.5) {
      aiCurrent = 9.2;
      aiPolicyAction = 'RL Thermal Guard (1.02C)';
    } else if (prev.aiTemp >= 34.5) {
      aiCurrent = 12.6;
      aiPolicyAction = 'RL Balanced Taper (1.40C)';
    } else if (prev.aiSoc >= 82) {
      aiCurrent = Math.max(4.5, 13.0 * (1 - (prev.aiSoc - 82) / 18));
      aiPolicyAction = 'RL Soft CV Relaxation';
    } else {
      aiCurrent = 17.5;
      aiPolicyAction = 'RL Cool-Window Boost (1.94C)';
    }
  }

  const aiR = computeInternalResistanceOhm(prev.aiSoh, prev.aiTemp, 1.0);
  const aiJoule = Math.pow(aiCurrent, 2) * aiR * 0.185;
  const aiCooling = (prev.aiTemp - ambient) * 0.145;
  const aiTemp = Math.min(43.5, Math.max(ambient, prev.aiTemp + aiJoule - aiCooling));
  const aiSoc = Math.min(95, prev.aiSoc + (aiCurrent / PACK_NOMINAL_AH) * (100 / 60) * 1.15);
  const aiVoltage = Number((computeCellOcv(aiSoc) * 3 + aiCurrent * aiR * 0.4).toFixed(2));
  const aiFadeMpct =
    computeCycleDegradationPct(aiCurrent, aiTemp, PACK_NOMINAL_AH, 60) * 1000 * 3.8;
  const aiHealthLossMpct = prev.aiHealthLossMpct + aiFadeMpct;
  const aiSoh = Number((95.0 - aiHealthLossMpct / 1000).toFixed(4));

  return {
    minute,
    fastSoc: Number(fastSoc.toFixed(1)),
    aiSoc: Number(aiSoc.toFixed(1)),
    fastTemp: Number(fastTemp.toFixed(2)),
    aiTemp: Number(aiTemp.toFixed(2)),
    fastCurrent: Number(fastCurrent.toFixed(2)),
    aiCurrent: Number(aiCurrent.toFixed(2)),
    fastVoltage,
    aiVoltage,
    fastHealthLossMpct: Number(fastHealthLossMpct.toFixed(2)),
    aiHealthLossMpct: Number(aiHealthLossMpct.toFixed(2)),
    fastSoh,
    aiSoh,
    aiPolicyAction,
  };
}

export function summarizeDualCharge(history: DualChargeSnapshot[]): DualChargeSummary {
  if (history.length === 0) {
    return {
      fastPeakTemp: 28,
      aiPeakTemp: 28,
      coolerPeakTempPct: 0,
      tempReductionPct: 0,
      fastHealthLossMpct: 0,
      aiHealthLossMpct: 0,
      degradationReductionPct: 0,
      extendedLifespanPct: 0,
      fastDurationMin: 0,
      aiDurationMin: 0,
      estimatedExtraCycles: 0,
    };
  }
  const fastPeakTemp = Math.max(...history.map((h) => h.fastTemp));
  const aiPeakTemp = Math.max(...history.map((h) => h.aiTemp));
  const latest = history[history.length - 1];
  const tempRiseFast = Math.max(0.1, fastPeakTemp - 28);
  const tempRiseAi = Math.max(0.1, aiPeakTemp - 28);
  const tempReductionPct = Math.max(0, Math.round(((tempRiseFast - tempRiseAi) / tempRiseFast) * 100));
  const coolerPeakTempPct =
    fastPeakTemp > 0
      ? Math.max(0, Math.round(((fastPeakTemp - aiPeakTemp) / fastPeakTemp) * 100))
      : 0;
  const degradationReductionPct =
    latest.fastHealthLossMpct > 0
      ? Math.max(
          0,
          Math.round(((latest.fastHealthLossMpct - latest.aiHealthLossMpct) / latest.fastHealthLossMpct) * 100)
        )
      : 0;
  const extendedLifespanPct =
    latest.aiHealthLossMpct > 0
      ? Math.min(45, Math.round(((latest.fastHealthLossMpct / latest.aiHealthLossMpct) - 1) * 28))
      : 0;

  const fastFinish = history.find((h) => h.fastSoc >= 94.8)?.minute ?? latest.minute;
  const aiFinish = history.find((h) => h.aiSoc >= 94.8)?.minute ?? latest.minute;
  const estimatedExtraCycles = Math.round(degradationReductionPct * 4.2);

  return {
    fastPeakTemp: Number(fastPeakTemp.toFixed(1)),
    aiPeakTemp: Number(aiPeakTemp.toFixed(1)),
    coolerPeakTempPct,
    tempReductionPct,
    fastHealthLossMpct: Number(latest.fastHealthLossMpct.toFixed(1)),
    aiHealthLossMpct: Number(latest.aiHealthLossMpct.toFixed(1)),
    degradationReductionPct,
    extendedLifespanPct,
    fastDurationMin: fastFinish,
    aiDurationMin: aiFinish,
    estimatedExtraCycles,
  };
}

/**
 * Classifies retired EV battery packs:
 * Grade A (80-90%+): Grid / Solar Storage
 * Grade B (65-79%): Micro-mobility / UPS
 * Grade C (<65%): Recycling
 */
export function gradeSecondLifeBattery(sohPct: number): SecondLifeGrade {
  if (sohPct >= 80) {
    return {
      grade: 'A',
      title: 'Grade A (80–90%+): Grid / Solar Storage',
      useCase: 'Stationary utility peak-shaving, solar BESS farms & EV fleet range extension',
      valueRetentionPct: 72,
      accentHex: '#22E58B',
    };
  }
  if (sohPct >= 65) {
    return {
      grade: 'B',
      title: 'Grade B (65–79%): Micro-mobility / UPS',
      useCase: 'E-rickshaw / micro-mobility packs, telecom backup & commercial UPS buffers',
      valueRetentionPct: 48,
      accentHex: '#22D3EE',
    };
  }
  return {
    grade: 'C',
    title: 'Grade C (<65%): Recycling',
    useCase: 'Safe pack teardown & hydrometallurgical recovery of Li, Ni, Co & Cu',
    valueRetentionPct: 22,
    accentHex: '#EF4444',
  };
}

export function calculateValueSavings(packCostInr: number, extensionPct: number): {
  rupeesSaved: number;
  extraMonths: number;
} {
  const rupeesSaved = Math.round((packCostInr * extensionPct) / 100);
  const extraMonths = Math.round((96 * extensionPct) / 100);
  return { rupeesSaved, extraMonths };
}

export function calculateCo2Savings(packCount: number, extensionPct: number): {
  annualCo2Kg: number;
  treesEquivalent: number;
} {
  const avoidedPerPackKg = 4200 * (extensionPct / 100);
  const annualCo2Kg = Math.round(packCount * avoidedPerPackKg);
  const treesEquivalent = Math.round(annualCo2Kg / 21.7);
  return { annualCo2Kg, treesEquivalent };
}
