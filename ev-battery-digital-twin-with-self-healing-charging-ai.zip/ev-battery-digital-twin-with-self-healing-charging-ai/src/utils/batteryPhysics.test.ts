import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeCellOcv,
  computeCycleDegradationPct,
  computeThermalColorHex,
  createInitial3SPack,
  createInitialDualChargeState,
  stepDualChargeSimulation,
  stepPackTelemetry,
  summarizeDualCharge,
  gradeSecondLifeBattery,
  calculateValueSavings,
} from './batteryPhysics';
import { generateLstmCurveData } from './aiModels';
import { answerBatteryQuestionFromKnowledge } from './assistantKnowledge';

test('OCV curve increases monotonically from 0% to 100% SoC within Li-ion bounds', () => {
  const v0 = computeCellOcv(0);
  const v25 = computeCellOcv(25);
  const v50 = computeCellOcv(50);
  const v80 = computeCellOcv(80);
  const v100 = computeCellOcv(100);

  assert.ok(v0 >= 3.0 && v0 < v25);
  assert.ok(v25 < v50);
  assert.ok(v50 < v80);
  assert.ok(v80 < v100 && v100 <= 4.2);
});

test('Arrhenius degradation accelerates sharply above 38C and high current', () => {
  const mildFade = computeCycleDegradationPct(5, 28, 9, 60);
  const hotHighCurrentFade = computeCycleDegradationPct(20, 44, 9, 60);

  assert.ok(hotHighCurrentFade > mildFade * 10);
});

test('3S3P pack initializes 9 cylindrical cells across S1, S2, S3 banks', () => {
  const pack = createInitial3SPack(60, 94);
  assert.equal(pack.length, 9);
  assert.equal(pack.filter((c) => c.bank === 'S1').length, 3);
  assert.equal(pack.filter((c) => c.bank === 'S2').length, 3);
  assert.equal(pack.filter((c) => c.bank === 'S3').length, 3);
});

test('Auto-heal RL throttles current when cells exceed 40C threshold', () => {
  const hotPack = createInitial3SPack(60, 94).map((c) => ({ ...c, temperature: 41.2 }));
  const result = stepPackTelemetry(hotPack, {
    mode: 'charging',
    targetCurrentAmps: 14.0,
    autoHeal: true,
    ambientTempC: 27,
    thermalBoostActive: false,
    dtSeconds: 1,
  });

  assert.ok(result.effectiveCurrent <= 3.8);
  assert.match(result.rlActionNote, /Throttle/i);
});

test('Nominal 10A charging remains cool (<35C) while thermalBoostActive triggers >40C alert', () => {
  let pack = createInitial3SPack(60, 94);
  let maxTemp = 0;
  for (let i = 0; i < 20; i++) {
    const step = stepPackTelemetry(pack, {
      mode: 'charging',
      targetCurrentAmps: 10.0,
      autoHeal: true,
      ambientTempC: 27,
      thermalBoostActive: false,
      dtSeconds: 1,
    });
    pack = step.nextCells;
    maxTemp = step.maxTemp;
  }
  assert.ok(maxTemp < 35, `Expected nominal temp < 35C, got ${maxTemp}`);

  for (let i = 0; i < 16; i++) {
    const step = stepPackTelemetry(pack, {
      mode: 'charging',
      targetCurrentAmps: 10.0,
      autoHeal: true,
      ambientTempC: 27,
      thermalBoostActive: true,
      dtSeconds: 1,
    });
    pack = step.nextCells;
    maxTemp = step.maxTemp;
  }
  assert.ok(maxTemp > 40, `Expected thermal boost > 40C, got ${maxTemp}`);
});

test('AI adaptive charging finishes cooler and extends lifespan vs Fixed CC/CV Fast Charge', () => {
  let state = createInitialDualChargeState();
  const history = [state];
  for (let i = 0; i < 45; i++) {
    state = stepDualChargeSimulation(state);
    history.push(state);
  }
  const summary = summarizeDualCharge(history);
  assert.ok(summary.aiPeakTemp < summary.fastPeakTemp);
  assert.ok(summary.coolerPeakTempPct > 5);
  assert.ok(summary.extendedLifespanPct > 5);
  assert.ok(summary.aiHealthLossMpct < summary.fastHealthLossMpct);
});

test('Thermal color mapping produces valid hex codes across cool, warm, and hot ranges', () => {
  assert.match(computeThermalColorHex(26), /^#[0-9a-f]{6}$/i);
  assert.match(computeThermalColorHex(38), /^#[0-9a-f]{6}$/i);
  assert.match(computeThermalColorHex(45), /^#[0-9a-f]{6}$/i);
});

test('Second-life grading matches Grade A (80-90%), Grade B (65-79%), Grade C (<65%)', () => {
  assert.equal(gradeSecondLifeBattery(85).grade, 'A');
  assert.equal(gradeSecondLifeBattery(80).grade, 'A');
  assert.equal(gradeSecondLifeBattery(72).grade, 'B');
  assert.equal(gradeSecondLifeBattery(65).grade, 'B');
  assert.equal(gradeSecondLifeBattery(64).grade, 'C');

  assert.equal(calculateValueSavings(500000, 10).rupeesSaved, 50000);
  assert.equal(calculateValueSavings(500000, 20).rupeesSaved, 100000);
});

test('LSTM trajectory and assistant knowledge engine produce valid outputs', () => {
  const lstm = generateLstmCurveData();
  assert.ok(lstm.length >= 20);
  assert.ok(lstm[0].actualSoh > lstm[lstm.length - 1].actualSoh);

  const rlReply = answerBatteryQuestionFromKnowledge('How does the RL reward function work?');
  assert.match(rlReply, /reward/i);
  assert.match(rlReply, /temperature/i);
});
