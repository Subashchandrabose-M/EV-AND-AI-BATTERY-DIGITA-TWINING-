export interface AssistantReply {
  answer: string;
  source: 'builtin';
}

const KNOWLEDGE_RULES: Array<{ keywords: string[]; answer: string }> = [
  {
    keywords: ['physics', 'ocv', 'joule', 'heat', 'arrhenius', 'temperature', 'resistance', 'equation'],
    answer:
      'The 3S3P pack model runs three coupled electro-thermal equations every second: (1) a non-linear NMC Open-Circuit Voltage (OCV) vs. SoC curve (3.05V–4.20V), (2) I²R Joule heating per cell balanced against passive convective cooling to ambient temperature, and (3) Arrhenius-accelerated SoH capacity fade that spikes sharply above 38°C and high C-rates.',
  },
  {
    keywords: ['sense', 'learn', 'heal', 'pillar', 'architecture', 'closed-loop', 'loop'],
    answer:
      'The platform runs a closed Sense → Learn → Heal loop: ESP32 sensors stream cell voltage, current (INA219), and temperatures (DS18B20) into the 3D twin (Sense); an LSTM network modeled on NASA/CALCE aging data forecasts SoH and RUL (Learn); and an RL agent dynamically throttles MOSFET/buck charging current when thermal or high-SoC risk climbs (Heal).',
  },
  {
    keywords: ['hardware', 'wiring', 'esp32', 'ina219', 'ds18b20', 'sensor', 'bms', 'mosfet', 'buck', 'pin', 'i2c'],
    answer:
      'Hardware wiring overview: The 3S3P Li-ion pack connects through a hardware 3S BMS. An INA219 current/bus-voltage sensor talks to the ESP32 over I²C (SDA/SCL), three DS18B20 probes read cell bank temperatures via OneWire with a 4.7 kΩ pull-up resistor, and an ESP32 PWM/GPIO output drives the MOSFET/relay stage on the CC/CV buck converter.',
  },
  {
    keywords: ['lstm', 'forecast', 'rul', 'nasa', 'calce', 'confidence', 'knee'],
    answer:
      'The LSTM forecaster tracks historical capacity fade and projects future Remaining Useful Life (RUL) cycles down to the 80% End-of-Life threshold, including confidence bounds and early detection of the non-linear aging knee around ~650 cycles (simulated NASA B0005 / CALCE CS2 behavior).',
  },
  {
    keywords: ['rl', 'reinforcement', 'reward', 'function', 'policy', 'action', 'state', 'throttle', 'q-learning'],
    answer:
      'The RL controller observes state s_t = [Voltage, Current, Temperature, SoC] and chooses a current-taper action a_t. Its reward function maximizes charge progress while applying heavy negative penalties for crossing 36.5°C/40°C thermal thresholds, excessive I²R loss, and high-SoC (>82%) lithium-plating stress.',
  },
  {
    keywords: ['cost', 'budget', 'price', 'rupee', 'rs', 'roi', 'saving', 'value', 'bom'],
    answer:
      'The 3S3P prototype BOM stays compact (around ₹3,200–₹6,500 total across ESP32, INA219, 3× DS18B20, 3S BMS, cells, and MOSFET buck control). On a ₹5,00,000 EV battery pack, extending usable lifespan by 5%–20% preserves ₹25,000–₹1,00,000 in lifecycle value.',
  },
  {
    keywords: ['second', 'life', 'co2', 'carbon', 'grade', 'recycle', 'solar', 'grid'],
    answer:
      'Second-Life Grading classifies retired EV packs by State of Health: Grade A (80–90%+) routes to Grid/Solar Storage, Grade B (65–79%) serves Micro-mobility/UPS systems, and Grade C (<65%) routes safely to battery recycling—maximizing CO₂ offset.',
  },
  {
    keywords: ['fast', 'vs', 'compare', 'simulator', 'cc/cv', 'difference'],
    answer:
      'Fixed CC/CV fast charging holds high current until ~80% SoC regardless of temperature rise, causing steep Joule heating and accelerated SoH loss. The Self-Healing AI charger tapers current proactively as temperature approaches 37°C and softens above 82% SoC, delivering cooler peak temps and longer battery life.',
  },
];

export function answerBatteryQuestionFromKnowledge(question: string): string {
  const q = question.toLowerCase().trim();
  if (!q) {
    return 'Ask me about our electro-thermal battery physics, LSTM forecasting, RL reward function, hardware wiring, or second-life ROI!';
  }

  let bestScore = 0;
  let bestAnswer = '';

  for (const rule of KNOWLEDGE_RULES) {
    let score = 0;
    for (const kw of rule.keywords) {
      if (q.includes(kw)) {
        score += 1;
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestAnswer = rule.answer;
    }
  }

  if (bestScore > 0) {
    return bestAnswer;
  }

  return 'I am the Battery AI Copilot for the 3S3P Digital Twin. Try asking about "battery physics", "LSTM forecasting", "RL reward function", "hardware wiring", or "second-life grading".';
}
