import React, { useState } from 'react';
import { Calculator, IndianRupee, Info } from 'lucide-react';
import { calculateValueSavings } from '../utils/batteryPhysics';
import { AnimatedCounter, RevealSection } from './MotionPrimitives';

const BUDGET_ROWS = [
  { item: 'ESP32 Wi-Fi Microcontroller', qty: '1', min: 400, max: 600 },
  { item: 'INA219 Current / Power Sensor', qty: '1', min: 150, max: 350 },
  { item: 'DS18B20 Temperature Probes', qty: '3', min: 300, max: 900 },
  { item: 'Li-ion Cells + 3S BMS + Holders', qty: '1 set', min: 1500, max: 3000 },
  { item: 'Charger Control (CC/CV Buck + Relay/MOSFET)', qty: '1', min: 300, max: 600 },
  { item: 'Wires, Voltage Divider & Enclosure', qty: '1 lot', min: 500, max: 1000 },
];

const EXTENSION_PRESETS = [5, 10, 20];

export const CostValueSection: React.FC = () => {
  const [packCostInr, setPackCostInr] = useState<number>(500000);
  const [extensionPct, setExtensionPct] = useState<number>(10);

  const savings = calculateValueSavings(packCostInr, extensionPct);

  return (
    <section id="cost-value" className="py-20 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
              09 · Economics & Prototype Budget
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
              Cost & Value Calculator
            </h2>
            <p className="mt-2 text-slate-400 text-sm sm:text-base">
              Low-cost college prototype hardware paired with high-leverage lifecycle savings at EV pack scale.
            </p>
          </div>
        </RevealSection>

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Left 7 Cols: Prototype Budget Table in Rupees */}
          <RevealSection className="lg:col-span-7">
            <div className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-4">
                  <div className="flex items-center gap-2">
                    <IndianRupee className="w-4 h-4 text-[#22D3EE]" aria-hidden="true" />
                    <h3 className="font-display text-lg font-bold text-slate-100">
                      Prototype Hardware Budget (INR)
                    </h3>
                  </div>
                  <span className="font-mono text-xs text-slate-400">3S Bench Unit</span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="border-b border-white/10 text-xs font-mono uppercase text-slate-400">
                        <th className="py-2.5 pr-4 font-medium">Component</th>
                        <th className="py-2.5 px-3 font-medium">Qty</th>
                        <th className="py-2.5 pl-3 text-right font-medium">Est. Cost (₹)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {BUDGET_ROWS.map((row) => (
                        <tr key={row.item} className="hover:bg-white/[0.02]">
                          <td className="py-3 pr-4 text-slate-200">{row.item}</td>
                          <td className="py-3 px-3 font-mono text-xs text-slate-400 tabular-nums">
                            {row.qty}
                          </td>
                          <td className="py-3 pl-3 text-right font-mono text-slate-100 tabular-nums whitespace-nowrap">
                            ₹{row.min.toLocaleString('en-IN')} – ₹{row.max.toLocaleString('en-IN')}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-white/15 flex flex-wrap items-center justify-between gap-3">
                <span className="text-sm font-semibold text-slate-200">
                  TOTAL PROTOTYPE ESTIMATE
                </span>
                <div className="font-mono text-xl font-bold text-[#22E58B] tabular-nums">
                  ≈ ₹<AnimatedCounter value={3200} formatLocale /> – ₹
                  <AnimatedCounter value={6500} formatLocale />
                </div>
              </div>
            </div>
          </RevealSection>

          {/* Right 5 Cols: Interactive EV Pack Value Calculator */}
          <RevealSection delay={0.1} className="lg:col-span-5">
            <div className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Calculator className="w-4 h-4 text-[#22E58B]" aria-hidden="true" />
                  <h3 className="font-display text-lg font-bold text-slate-100">
                    EV Battery Value Extension
                  </h3>
                </div>
                <p className="mt-1 text-xs text-slate-400">
                  Explore projected lifecycle value preserved on a full EV battery pack.
                </p>

                {/* Pack Cost Slider */}
                <div className="mt-6">
                  <div className="flex justify-between text-xs mb-2">
                    <label htmlFor="pack-cost-slider" className="text-slate-300 font-medium">
                      EV Battery Pack Cost
                    </label>
                    <span className="font-mono text-sm font-bold text-slate-100 tabular-nums">
                      ₹{packCostInr.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <input
                    id="pack-cost-slider"
                    type="range"
                    min={150000}
                    max={1200000}
                    step={25000}
                    value={packCostInr}
                    onChange={(e) => setPackCostInr(Number(e.target.value))}
                    className="w-full telemetry-slider"
                  />
                  <div className="flex justify-between text-[11px] font-mono text-slate-500 mt-1">
                    <span>₹1,50,000</span>
                    <span>₹5,00,000</span>
                    <span>₹12,00,000</span>
                  </div>
                </div>

                {/* Battery Life Extension Preset Buttons + Slider */}
                <div className="mt-6">
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-slate-300 font-medium">Battery Life Extension</span>
                    <span className="font-mono text-sm font-bold text-[#22E58B] tabular-nums">
                      +{extensionPct}%
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-3">
                    {EXTENSION_PRESETS.map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => setExtensionPct(pct)}
                        className={`py-2 rounded-lg font-mono text-xs font-semibold border transition-colors cursor-pointer ${
                          extensionPct === pct
                            ? 'bg-[#22E58B] text-[#070A0F] border-[#22E58B]'
                            : 'bg-white/[0.04] text-slate-200 border-white/10 hover:border-white/25'
                        }`}
                      >
                        +{pct}% Life
                      </button>
                    ))}
                  </div>
                  <input
                    aria-label="Custom battery life extension percentage"
                    type="range"
                    min={5}
                    max={25}
                    step={1}
                    value={extensionPct}
                    onChange={(e) => setExtensionPct(Number(e.target.value))}
                    className="w-full telemetry-slider"
                  />
                </div>

                {/* Animated Savings Result */}
                <div className="mt-6 rounded-xl bg-[#22E58B]/10 border border-[#22E58B]/35 p-4">
                  <div className="text-xs font-mono uppercase tracking-wider text-[#22E58B]">
                    Projected Pack Value Preserved
                  </div>
                  <div className="mt-1 text-3xl font-extrabold text-slate-100">
                    <AnimatedCounter value={savings.rupeesSaved} prefix="₹" formatLocale />
                  </div>
                  <div className="mt-1 text-xs font-mono text-slate-300 tabular-nums">
                    Approx. +{savings.extraMonths} months of usable pack horizon (8-yr baseline)
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-white/10 flex items-start gap-2.5 text-xs text-slate-400">
                <Info className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" aria-hidden="true" />
                <span>
                  Assumptions, not measured results. Prototype tests will validate real gain.
                </span>
              </div>
            </div>
          </RevealSection>
        </div>
      </div>
    </section>
  );
};
