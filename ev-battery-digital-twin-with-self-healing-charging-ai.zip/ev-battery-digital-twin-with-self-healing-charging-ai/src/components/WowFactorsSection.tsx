import React, { useState } from 'react';
import { Award, Battery, Flame, Leaf, ThermometerSun, Wallet } from 'lucide-react';
import {
  calculateCo2Savings,
  gradeSecondLifeBattery,
} from '../utils/batteryPhysics';
import { AnimatedCounter, RevealSection } from './MotionPrimitives';

interface WowFactorsSectionProps {
  heatmapMode: boolean;
  onToggleHeatmap: () => void;
}

const IMPACT_KPI = [
  {
    label: 'Longer battery life',
    value: 18,
    suffix: '%',
    sub: 'Projected cycle extension via thermal control',
    icon: Battery,
    color: '#22E58B',
  },
  {
    label: 'Cooler safer charging',
    value: 7.4,
    decimals: 1,
    prefix: '-',
    suffix: '°C',
    sub: 'Lower peak cell temperature during fast charge',
    icon: ThermometerSun,
    color: '#22D3EE',
  },
  {
    label: 'Lower ownership cost',
    value: 50000,
    prefix: '₹',
    formatLocale: true,
    sub: 'Potential value saved on a ₹5L EV pack (10% gain)',
    icon: Wallet,
    color: '#22E58B',
  },
  {
    label: 'Lower CO2 footprint',
    value: 420,
    suffix: ' kg',
    sub: 'Embodied carbon deferred per pack extended 10%',
    icon: Leaf,
    color: '#22D3EE',
  },
];

export const WowFactorsSection: React.FC<WowFactorsSectionProps> = ({
  heatmapMode,
  onToggleHeatmap,
}) => {
  const [sohInput, setSohInput] = useState<number>(82);
  const [fleetSize, setFleetSize] = useState<number>(10);
  const [fleetExtensionPct, setFleetExtensionPct] = useState<number>(12);

  const grade = gradeSecondLifeBattery(sohInput);
  const co2 = calculateCo2Savings(fleetSize, fleetExtensionPct);

  const ringRadius = 46;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset = ringCircumference * (1 - sohInput / 100);

  return (
    <section id="impact" className="py-20 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
              07 · Value & Sustainability Add-Ons
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
              Measurable Impact & Working Mini-Demos
            </h2>
            <p className="mt-2 text-slate-400 text-sm sm:text-base">
              Beyond protection, live SoH telemetry unlocks second-life battery grading, carbon tracking, and cell-level thermal heatmaps.
            </p>
          </div>
        </RevealSection>

        {/* 4 Impact Counters */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {IMPACT_KPI.map((kpi, idx) => {
            const Icon = kpi.icon;
            return (
              <RevealSection key={kpi.label} delay={idx * 0.05}>
                <div className="glass-panel rounded-xl p-5 h-full flex flex-col justify-between">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-400">{kpi.label}</span>
                    <Icon className="w-4 h-4" style={{ color: kpi.color }} aria-hidden="true" />
                  </div>
                  <div className="mt-3 text-3xl font-bold text-slate-100">
                    <AnimatedCounter
                      value={kpi.value}
                      decimals={kpi.decimals ?? 0}
                      prefix={kpi.prefix ?? ''}
                      suffix={kpi.suffix ?? ''}
                      formatLocale={kpi.formatLocale}
                    />
                  </div>
                  <p className="mt-2 text-xs text-slate-400">{kpi.sub}</p>
                </div>
              </RevealSection>
            );
          })}
        </div>

        {/* 3 Working Mini-Demos */}
        <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Mini-Demo A: Second-Life Battery Grading */}
          <RevealSection>
            <div className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                  <Award className="w-4 h-4 text-[#22E58B]" aria-hidden="true" />
                  <h3>Second-Life Battery Grading</h3>
                </div>
                <p className="mt-1 text-xs text-slate-400">
                  Adjust State of Health (SoH) to classify retired EV packs into Grade A, B, or C.
                </p>

                <div className="mt-5 flex items-center gap-5">
                  <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
                    <svg viewBox="0 0 108 108" className="w-full h-full -rotate-90" aria-hidden="true">
                      <circle
                        cx="54"
                        cy="54"
                        r={ringRadius}
                        fill="none"
                        stroke="rgba(148,163,184,0.14)"
                        strokeWidth="8"
                      />
                      <circle
                        cx="54"
                        cy="54"
                        r={ringRadius}
                        fill="none"
                        stroke={grade.accentHex}
                        strokeWidth="8"
                        strokeLinecap="round"
                        strokeDasharray={ringCircumference}
                        strokeDashoffset={ringOffset}
                        style={{ transition: 'stroke-dashoffset 250ms ease, stroke 250ms ease' }}
                      />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span
                        className="font-display text-2xl font-extrabold leading-none"
                        style={{ color: grade.accentHex }}
                      >
                        {grade.grade}
                      </span>
                      <span className="font-mono text-xs text-slate-300 mt-1 tabular-nums">
                        {sohInput}% SoH
                      </span>
                    </div>
                  </div>

                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-100">{grade.title}</div>
                    <p className="mt-1 text-xs text-slate-400 leading-relaxed">{grade.useCase}</p>
                    <div className="mt-2 font-mono text-xs text-[#22D3EE]">
                      Resale Value: ~{grade.valueRetentionPct}%
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-5">
                <div className="flex justify-between text-xs mb-1.5">
                  <label htmlFor="second-life-soh" className="text-slate-300">
                    Test Pack SoH (%)
                  </label>
                  <span className="font-mono text-[#22E58B] tabular-nums">{sohInput}%</span>
                </div>
                <input
                  id="second-life-soh"
                  type="range"
                  min={55}
                  max={98}
                  step={1}
                  value={sohInput}
                  onChange={(e) => setSohInput(Number(e.target.value))}
                  className="w-full telemetry-slider"
                />
              </div>
            </div>
          </RevealSection>

          {/* Mini-Demo B: Carbon (CO2) Savings Tracker */}
          <RevealSection delay={0.08}>
            <div className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                  <Leaf className="w-4 h-4 text-[#22D3EE]" aria-hidden="true" />
                  <h3>Carbon (CO2) Savings Tracker</h3>
                </div>
                <p className="mt-1 text-xs text-slate-400">
                  Estimate embodied manufacturing CO2 avoided by extending EV pack lifespans.
                </p>

                <div className="mt-5 rounded-xl bg-[#070A0F]/80 border border-white/10 p-4">
                  <div className="text-xs font-mono text-slate-400">Embodied CO2 Avoided</div>
                  <div className="mt-1 text-3xl font-bold text-[#22E58B]">
                    <AnimatedCounter value={co2.annualCo2Kg} formatLocale suffix=" kg CO2" />
                  </div>
                  <div className="mt-1.5 text-xs font-mono text-[#22D3EE] tabular-nums">
                    ≈ {co2.treesEquivalent.toLocaleString('en-IN')} mature trees absorbing CO2 / yr
                  </div>
                </div>
              </div>

              <div className="mt-5 space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <label htmlFor="co2-fleet-slider" className="text-slate-300">
                      EV Fleet Size
                    </label>
                    <span className="font-mono text-slate-100 tabular-nums">
                      {fleetSize} vehicles
                    </span>
                  </div>
                  <input
                    id="co2-fleet-slider"
                    type="range"
                    min={1}
                    max={100}
                    step={1}
                    value={fleetSize}
                    onChange={(e) => setFleetSize(Number(e.target.value))}
                    className="w-full telemetry-slider"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <label htmlFor="co2-ext-slider" className="text-slate-300">
                      Life Extension
                    </label>
                    <span className="font-mono text-[#22E58B] tabular-nums">
                      +{fleetExtensionPct}%
                    </span>
                  </div>
                  <input
                    id="co2-ext-slider"
                    type="range"
                    min={5}
                    max={25}
                    step={1}
                    value={fleetExtensionPct}
                    onChange={(e) => setFleetExtensionPct(Number(e.target.value))}
                    className="w-full telemetry-slider"
                  />
                </div>
              </div>
            </div>
          </RevealSection>

          {/* Mini-Demo C: 3D Cell-Level Heatmap Sync Toggle */}
          <RevealSection delay={0.16}>
            <div className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                  <Flame className="w-4 h-4 text-[#F59E0B]" aria-hidden="true" />
                  <h3>3D Cell-Level Thermal Heatmap</h3>
                </div>
                <p className="mt-1 text-xs text-slate-400">
                  Switch the live 3D Digital Twin cells into high-contrast thermal emissivity mode to spot hot core cells instantly.
                </p>

                {/* Live Mini Thermal Grid Preview */}
                <div className="mt-5 grid grid-cols-4 gap-2">
                  {[29.8, 31.2, 31.4, 29.9, 32.1, 35.8, 36.2, 32.4, 30.2, 31.6, 31.5, 29.7].map(
                    (temp, i) => (
                      <div
                        key={i}
                        className="rounded-md p-2 text-center font-mono text-[11px] tabular-nums border border-white/10 transition-all"
                        style={{
                          backgroundColor: heatmapMode
                            ? temp > 35
                              ? 'rgba(239, 68, 68, 0.32)'
                              : temp > 32
                                ? 'rgba(245, 158, 11, 0.28)'
                                : 'rgba(34, 229, 139, 0.24)'
                            : 'rgba(255, 255, 255, 0.03)',
                        }}
                      >
                        <div className="text-slate-300">C{i + 1}</div>
                        <div className="text-slate-100 font-semibold">{temp}°</div>
                      </div>
                    )
                  )}
                </div>
              </div>

              <div className="mt-5 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={onToggleHeatmap}
                  aria-pressed={heatmapMode}
                  className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    heatmapMode
                      ? 'bg-[#F59E0B] text-[#070A0F]'
                      : 'bg-white/[0.06] hover:bg-white/[0.12] text-slate-100 border border-white/15'
                  }`}
                >
                  {heatmapMode ? 'Disable 3D Heatmap' : 'Enable 3D Heatmap'}
                </button>
                <a
                  href="#live-twin"
                  className="py-2.5 px-3.5 rounded-lg bg-[#22D3EE]/12 border border-[#22D3EE]/35 text-xs font-semibold text-[#22D3EE] hover:bg-[#22D3EE]/20 whitespace-nowrap"
                >
                  View in 3D
                </a>
              </div>
            </div>
          </RevealSection>
        </div>
      </div>
    </section>
  );
};
