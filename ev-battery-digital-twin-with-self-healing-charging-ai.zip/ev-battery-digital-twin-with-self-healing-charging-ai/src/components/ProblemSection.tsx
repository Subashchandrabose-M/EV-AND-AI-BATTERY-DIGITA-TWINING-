import React from 'react';
import { AlertTriangle, BatteryWarning, EyeOff, Flame, Recycle } from 'lucide-react';
import { RevealSection } from './MotionPrimitives';

const PROBLEMS = [
  {
    title: 'Costly wear-out',
    icon: BatteryWarning,
    metric: '35–45% EV Value',
    description:
      'Battery packs are the single costliest EV component. Uncontrolled thermal and C-rate stress accelerates premature replacement.',
    tone: '#F59E0B',
  },
  {
    title: 'Blind charging',
    icon: Flame,
    metric: 'Fixed CC/CV',
    description:
      'Conventional chargers push fixed current curves regardless of cell temperature rise, internal resistance, or aging state.',
    tone: '#EF4444',
  },
  {
    title: 'No foresight',
    icon: EyeOff,
    metric: 'Reactive BMS',
    description:
      'Basic BMS hardware only trips at emergency voltage/heat cut-offs instead of predicting State of Health (SoH) and Remaining Useful Life.',
    tone: '#22D3EE',
  },
  {
    title: 'Wasted second life',
    icon: Recycle,
    metric: 'Unverified SoH',
    description:
      'Without cell-level degradation logs, retired EV packs cannot be confidently graded for solar microgrids and end up scrapped early.',
    tone: '#22E58B',
  },
];

export const ProblemSection: React.FC = () => {
  return (
    <section id="problem" className="py-20 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-widest text-[#22D3EE]">
              01 · Why Batteries Degrade Early
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
              The Problem with Static EV Charging
            </h2>
            <p className="mt-3 text-slate-400 text-base">
              Standard Battery Management Systems protect against catastrophic failure, yet miss the daily micro-stressors that silently erode cycle life.
            </p>
          </div>
        </RevealSection>

        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {PROBLEMS.map((item, idx) => {
            const Icon = item.icon;
            return (
              <RevealSection key={item.title} delay={idx * 0.06}>
                <article className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between hover:border-white/20 transition-colors">
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center border border-white/10"
                        style={{ backgroundColor: `${item.tone}14`, color: item.tone }}
                      >
                        <Icon className="w-5 h-5" aria-hidden="true" />
                      </div>
                      <span className="font-mono text-xs text-slate-400">{item.metric}</span>
                    </div>
                    <h3 className="mt-5 font-display text-lg font-semibold text-slate-100">
                      {item.title}
                    </h3>
                    <p className="mt-2 text-sm text-slate-400 leading-relaxed">{item.description}</p>
                  </div>
                </article>
              </RevealSection>
            );
          })}
        </div>

        {/* Highlighted THE GAP banner */}
        <RevealSection delay={0.2}>
          <div className="mt-8 rounded-xl border border-[#F59E0B]/35 bg-gradient-to-r from-[#F59E0B]/10 via-[#0F1724] to-[#22E58B]/10 p-6 sm:p-7 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="w-11 h-11 rounded-lg bg-[#F59E0B]/15 border border-[#F59E0B]/40 text-[#F59E0B] flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5" aria-hidden="true" />
              </div>
              <div>
                <p className="font-mono text-xs font-semibold uppercase tracking-widest text-[#F59E0B]">
                  The Gap
                </p>
                <p className="mt-1 text-base sm:text-lg font-semibold text-slate-100">
                  No affordable system learns battery health live and dynamically adapts charging to slow degradation.
                </p>
              </div>
            </div>
            <a
              href="#solution"
              className="px-4 py-2 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-xs font-semibold text-slate-100 whitespace-nowrap shrink-0 transition-colors"
            >
              See Our Solution
            </a>
          </div>
        </RevealSection>
      </div>
    </section>
  );
};
