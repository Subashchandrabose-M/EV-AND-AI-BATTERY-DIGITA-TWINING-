import React, { useState } from 'react';
import {
  AlertTriangle,
  Flame,
  Pause,
  Play,
  RotateCcw,
  ShieldCheck,
  Thermometer,
  X,
  Zap,
} from 'lucide-react';
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { useBatterySimulation } from '../hooks/useBatterySimulation';
import { computeThermalColorHex } from '../utils/batteryPhysics';
import { BatteryPack3D } from './BatteryPack3D';
import { ArcGauge } from './MotionPrimitives';

type BatterySimHandle = ReturnType<typeof useBatterySimulation>;

interface LiveTwinDashboardProps {
  sim: BatterySimHandle;
  heatmapMode: boolean;
  onToggleHeatmap: () => void;
}

export const LiveTwinDashboard: React.FC<LiveTwinDashboardProps> = ({
  sim,
  heatmapMode,
  onToggleHeatmap,
}) => {
  const [selectedCellId, setSelectedCellId] = useState<string>('S2-C2');
  const [activeChart, setActiveChart] = useState<'all' | 'voltage' | 'temp'>('all');

  const selectedCell =
    sim.cells.find((c) => c.id === selectedCellId) ?? sim.cells[0];

  const tempGaugeColor =
    sim.maxTemp > 40 ? '#EF4444' : sim.maxTemp >= 35.5 ? '#F59E0B' : '#22E58B';

  return (
    <section aria-label="Live Digital Twin Cockpit" className="py-8 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Header & Stream Controls */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
              Cockpit View 01 · 3S3P Electro-Thermal Digital Twin
            </p>
            <h1 className="mt-1.5 font-display text-2xl sm:text-3xl font-bold text-slate-100">
              EV Battery Digital Twin & Self-Healing AI
            </h1>
            <p className="mt-1 text-slate-400 text-sm max-w-2xl">
              Live ESP32 + INA219 + DS18B20 telemetry synced to a 9-cell 3D pack with real-time LSTM health estimation and RL current throttling.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => sim.setIsStreaming((s) => !s)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-100 cursor-pointer transition-colors whitespace-nowrap shrink-0"
            >
              {sim.isStreaming ? (
                <>
                  <Pause className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
                  <span>Pause Stream</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 text-[#22E58B]" aria-hidden="true" />
                  <span>Resume Stream</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={sim.resetPack}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 cursor-pointer transition-colors whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Reset Pack</span>
            </button>
          </div>
        </div>

        {/* Thermal threshold alert toast (> 40°C) */}
        {sim.thermalAlert?.active && (
          <div
            role="alert"
            className="rounded-xl border border-[#EF4444]/50 bg-[#EF4444]/15 px-4 py-3 flex items-center justify-between gap-4 shadow-[0_8px_30px_rgba(239,68,68,0.18)]"
          >
            <div className="flex items-center gap-3 text-sm text-slate-100">
              <AlertTriangle className="w-5 h-5 text-[#EF4444] shrink-0" aria-hidden="true" />
              <span>{sim.thermalAlert.message}</span>
            </div>
            <button
              type="button"
              onClick={sim.dismissAlert}
              aria-label="Dismiss thermal alert"
              className="p-1.5 rounded-lg hover:bg-white/10 text-slate-300 shrink-0 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Top Animated Health & Charge Gauges */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <ArcGauge
            label="State of Charge (SoC)"
            value={sim.packSoc}
            max={100}
            displayValue={`${sim.packSoc.toFixed(1)}`}
            unit="%"
            sublabel={sim.mode === 'charging' ? 'Charging Active' : 'EV Drive Load'}
            colorHex="#22D3EE"
          />
          <ArcGauge
            label="State of Health (SoH)"
            value={sim.packSoh}
            max={100}
            displayValue={`${sim.packSoh.toFixed(1)}`}
            unit="%"
            sublabel="LSTM Estimated"
            colorHex="#22E58B"
          />
          <ArcGauge
            label="Remaining Useful Life"
            value={sim.rulCycles}
            max={1000}
            displayValue={`${sim.rulCycles}`}
            unit="Cycles"
            sublabel="To 80% EoL Limit"
            colorHex={tempGaugeColor}
          />
          <div className="glass-panel rounded-xl p-4 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Pack Electrical Bus</span>
              <span className="font-mono text-[#22E58B] truncate max-w-[145px]">
                {sim.rlActionNote}
              </span>
            </div>
            <div className="mt-2 grid grid-cols-3 gap-2 font-mono tabular-nums">
              <div>
                <div className="text-[11px] text-slate-400">Voltage</div>
                <div className="text-lg font-bold text-slate-100">
                  {sim.packVoltage.toFixed(2)}
                  <span className="text-xs font-normal text-slate-400">V</span>
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-400">Current</div>
                <div className="text-lg font-bold text-[#22D3EE]">
                  {sim.effectiveCurrent > 0
                    ? `+${sim.effectiveCurrent.toFixed(1)}`
                    : sim.effectiveCurrent.toFixed(1)}
                  <span className="text-xs font-normal text-slate-400">A</span>
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-400">Peak Temp</div>
                <div className="text-lg font-bold" style={{ color: tempGaugeColor }}>
                  {sim.maxTemp.toFixed(1)}
                  <span className="text-xs font-normal text-slate-400">°C</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Twin Grid: 3D Pack + Manual Stress Controls & Live Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left 7 cols: 3D Pack + 9-Cell Matrix */}
          <div className="lg:col-span-7 space-y-4">
            <BatteryPack3D
              cells={sim.cells}
              heatmapMode={heatmapMode}
              onToggleHeatmap={onToggleHeatmap}
              selectedCellId={selectedCellId}
              onSelectCell={setSelectedCellId}
            />

            {/* 9-Cell 3S3P Interactive Matrix Selector */}
            <div className="glass-panel rounded-xl p-4">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <h2 className="text-sm font-semibold text-slate-200">
                  3S3P Cell Matrix Telemetry (9 Cylindrical Cells)
                </h2>
                <span className="text-xs font-mono text-slate-300 tabular-nums">
                  {selectedCell.label} · {selectedCell.voltage.toFixed(3)} V ·{' '}
                  {selectedCell.temperature.toFixed(1)} °C · {selectedCell.internalResistanceMohm} mΩ
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {sim.cells.map((cell) => {
                  const color = computeThermalColorHex(cell.temperature);
                  const active = cell.id === selectedCellId;
                  return (
                    <button
                      key={cell.id}
                      type="button"
                      onClick={() => setSelectedCellId(cell.id)}
                      className={`p-2.5 rounded-lg border text-left transition-colors cursor-pointer font-mono tabular-nums ${
                        active
                          ? 'border-[#22E58B] bg-[#22E58B]/10'
                          : 'border-slate-800 bg-slate-950/50 hover:border-slate-600'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-semibold text-slate-200">{cell.id}</span>
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: color }}
                          aria-hidden="true"
                        />
                      </div>
                      <div className="mt-1 text-xs font-semibold text-slate-100">
                        {cell.temperature.toFixed(1)}°C
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center justify-between">
                        <span>{cell.voltage.toFixed(2)}V</span>
                        <span>{cell.internalResistanceMohm}mΩ</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right 5 cols: Manual Stress Controls + Live Recharts */}
          <div className="lg:col-span-5 space-y-4">
            {/* Manual Stress Control Deck */}
            <div className="glass-panel rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-semibold text-slate-100">
                  Manual Stress & RL Healing Controls
                </h2>
                <div className="inline-flex rounded-lg bg-slate-950/60 p-0.5 border border-slate-800">
                  <button
                    type="button"
                    onClick={() => sim.setMode('charging')}
                    className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                      sim.mode === 'charging'
                        ? 'bg-[#22E58B] text-[#05080F]'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    Charge
                  </button>
                  <button
                    type="button"
                    onClick={() => sim.setMode('discharging')}
                    className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                      sim.mode === 'discharging'
                        ? 'bg-[#22D3EE] text-[#05080F]'
                        : 'text-slate-300 hover:text-white'
                    }`}
                  >
                    Drive Load
                  </button>
                </div>
              </div>

              {/* Ambient Temperature Slider */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <label
                    htmlFor="twin-ambient-slider"
                    className="text-slate-300 font-medium inline-flex items-center gap-1.5"
                  >
                    <Thermometer className="w-3.5 h-3.5 text-[#F59E0B]" aria-hidden="true" />
                    <span>Ambient Temperature</span>
                  </label>
                  <span className="font-mono tabular-nums text-[#F59E0B] font-semibold">
                    {sim.ambientTempC.toFixed(0)} °C
                  </span>
                </div>
                <input
                  id="twin-ambient-slider"
                  type="range"
                  min={20}
                  max={44}
                  step={1}
                  value={sim.ambientTempC}
                  onChange={(e) => sim.setAmbientTempC(Number(e.target.value))}
                  className="w-full telemetry-slider"
                />
              </div>

              {/* Load / Charge Current Slider */}
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <label htmlFor="twin-current-slider" className="text-slate-300 font-medium">
                    Load / Charge Current
                  </label>
                  <span className="font-mono tabular-nums text-[#22D3EE] font-semibold">
                    {sim.targetCurrentAmps.toFixed(1)} A
                  </span>
                </div>
                <input
                  id="twin-current-slider"
                  type="range"
                  min={3}
                  max={22}
                  step={0.5}
                  value={sim.targetCurrentAmps}
                  onChange={(e) => sim.setTargetCurrentAmps(Number(e.target.value))}
                  className="w-full telemetry-slider"
                />
              </div>

              {/* AI Healing Toggle (ON vs OFF) + Heat Spike Button */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={() => sim.setAutoHeal((v) => !v)}
                  aria-pressed={sim.autoHeal}
                  className={`inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    sim.autoHeal
                      ? 'bg-[#22E58B]/15 border-[#22E58B]/50 text-[#22E58B]'
                      : 'bg-slate-950/60 border-slate-700 text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{sim.autoHeal ? 'AI Healing: ON' : 'AI Healing: OFF'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => sim.setThermalBoostActive((v) => !v)}
                  aria-pressed={sim.thermalBoostActive}
                  className={`inline-flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-lg border text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    sim.thermalBoostActive
                      ? 'bg-[#EF4444]/20 border-[#EF4444]/60 text-[#EF4444]'
                      : 'bg-slate-950/60 border-slate-700 text-slate-200 hover:border-[#F59E0B]/50'
                  }`}
                >
                  <Flame className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>
                    {sim.thermalBoostActive ? 'Stop Thermal Spike' : 'Simulate Heat Spike'}
                  </span>
                </button>
              </div>
            </div>

            {/* Live Recharts Panel */}
            <div className="glass-panel rounded-xl p-5">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-[#22D3EE]" aria-hidden="true" />
                  <h2 className="text-sm font-semibold text-slate-100">
                    Live Telemetry Streams
                  </h2>
                </div>
                <div className="inline-flex rounded-lg bg-slate-950/60 p-0.5 border border-slate-800 text-xs">
                  {(['all', 'voltage', 'temp'] as const).map((tab) => (
                    <button
                      key={tab}
                      type="button"
                      onClick={() => setActiveChart(tab)}
                      className={`px-2.5 py-1 rounded-md font-medium cursor-pointer whitespace-nowrap ${
                        activeChart === tab
                          ? 'bg-slate-800 text-white'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {tab === 'all' ? 'All' : tab === 'voltage' ? 'V & A' : 'Multi-Cell °C'}
                    </button>
                  ))}
                </div>
              </div>

              {(activeChart === 'all' || activeChart === 'voltage') && (
                <div className="mb-4">
                  <p className="text-[11px] font-mono text-slate-400 mb-1.5">
                    Pack Voltage (V) & Charging Current (A)
                  </p>
                  <div className="h-36 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={sim.history}>
                        <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                        <XAxis
                          dataKey="timeLabel"
                          tick={{ fill: '#64748B', fontSize: 10 }}
                          tickLine={false}
                          minTickGap={22}
                        />
                        <YAxis
                          yAxisId="left"
                          domain={[9.5, 13.0]}
                          tick={{ fill: '#22E58B', fontSize: 10 }}
                          width={34}
                        />
                        <YAxis
                          yAxisId="right"
                          orientation="right"
                          domain={[-24, 24]}
                          tick={{ fill: '#22D3EE', fontSize: 10 }}
                          width={32}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#0B101B',
                            borderColor: 'rgb(30,41,59)',
                            borderRadius: '8px',
                            fontSize: '12px',
                          }}
                        />
                        <Line
                          yAxisId="left"
                          type="monotone"
                          dataKey="packVoltage"
                          name="Voltage (V)"
                          stroke="#22E58B"
                          strokeWidth={2}
                          dot={false}
                          isAnimationActive={false}
                        />
                        <Line
                          yAxisId="right"
                          type="monotone"
                          dataKey="current"
                          name="Current (A)"
                          stroke="#22D3EE"
                          strokeWidth={2}
                          dot={false}
                          isAnimationActive={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {(activeChart === 'all' || activeChart === 'temp') && (
                <div>
                  <p className="text-[11px] font-mono text-slate-400 mb-1.5">
                    Multi-Cell Bank Temperatures (°C · 40°C Alert Line)
                  </p>
                  <div className="h-40 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={sim.history}>
                        <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                        <XAxis
                          dataKey="timeLabel"
                          tick={{ fill: '#64748B', fontSize: 10 }}
                          tickLine={false}
                          minTickGap={22}
                        />
                        <YAxis
                          domain={[20, 50]}
                          tick={{ fill: '#F59E0B', fontSize: 10 }}
                          width={34}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: '#0B101B',
                            borderColor: 'rgb(30,41,59)',
                            borderRadius: '8px',
                            fontSize: '12px',
                          }}
                        />
                        <Legend wrapperStyle={{ fontSize: '10px' }} />
                        <ReferenceLine
                          y={40}
                          stroke="#EF4444"
                          strokeDasharray="4 4"
                          strokeOpacity={0.75}
                        />
                        <Line
                          type="monotone"
                          dataKey="s1Temp"
                          name="S1 Bank (°C)"
                          stroke="#22E58B"
                          strokeWidth={1.8}
                          dot={false}
                          isAnimationActive={false}
                        />
                        <Line
                          type="monotone"
                          dataKey="s2Temp"
                          name="S2 Core (°C)"
                          stroke="#EF4444"
                          strokeWidth={2}
                          dot={false}
                          isAnimationActive={false}
                        />
                        <Line
                          type="monotone"
                          dataKey="s3Temp"
                          name="S3 Bank (°C)"
                          stroke="#22D3EE"
                          strokeWidth={1.8}
                          dot={false}
                          isAnimationActive={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
