import React, { useState } from 'react';
import { Award, Calculator, Cpu, IndianRupee, Info, Leaf } from 'lucide-react';
import {
  calculateCo2Savings,
  calculateValueSavings,
  gradeSecondLifeBattery,
} from '../utils/batteryPhysics';
import { AnimatedCounter } from './MotionPrimitives';

const PROTOTYPE_BOM = [
  { part: 'ESP32 Wi-Fi + BLE MCU', role: '1 Hz MQTT & PWM gate control', estInr: '₹400 – ₹600' },
  { part: 'INA219 Current Sensor', role: 'High-side I²C voltage & current', estInr: '₹150 – ₹350' },
  { part: 'DS18B20 Temp Probes (×3)', role: 'Per-bank OneWire thermometry', estInr: '₹300 – ₹900' },
  { part: '3S BMS + 3S3P Li-ion Cells', role: 'Cell protection & pack hardware', estInr: '₹1,500 – ₹3,000' },
  { part: 'MOSFET Buck Module + Relay', role: 'CC/CV adaptive current actuation', estInr: '₹300 – ₹600' },
];

const EXTENSION_PRESETS = [5, 10, 15, 20];

export const SecondLifeAndRoiView: React.FC = () => {
  const [sohInput, setSohInput] = useState<number>(82);
  const [fleetSize, setFleetSize] = useState<number>(5);
  const [packCostInr, setPackCostInr] = useState<number>(500000);
  const [extensionPct, setExtensionPct] = useState<number>(10);

  const grade = gradeSecondLifeBattery(sohInput);
  const co2 = calculateCo2Savings(fleetSize, extensionPct);
  const savings = calculateValueSavings(packCostInr, extensionPct);

  const ringRadius = 46;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const ringOffset = ringCircumference * (1 - sohInput / 100);

  return (
    <section aria-label="Second-Life Grading and EV Value Calculator" className="py-8 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        {/* Header */}
        <div>
          <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
            Cockpit View 04 · Circular Economy & Ownership Economics
          </p>
          <h1 className="mt-1.5 font-display text-2xl sm:text-3xl font-bold text-slate-100">
            Second-Life Battery Grader & EV Value Calculator
          </h1>
          <p className="mt-1 text-slate-400 text-sm max-w-2xl">
            Classify retired EV battery packs by State of Health, quantify embodied CO₂ offset, and estimate lifecycle INR savings alongside our compact prototype BOM.
          </p>
        </div>

        {/* Row 1: Second-Life Grader + CO2 Offset Counter */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 glass-panel rounded-xl p-6 flex flex-col justify-between space-y-6">
            <div>
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#22E58B]" aria-hidden="true" />
                <h2 className="font-display text-lg font-bold text-slate-100">
                  Second-Life Battery Grader
                </h2>
              </div>
              <p className="mt-1 text-xs text-slate-400">
                Slide retired pack State of Health (SoH) to classify into Grade A (80–90%), Grade B (65–79%), or Grade C (&lt;65%).
              </p>

              <div className="mt-5 flex flex-col sm:flex-row sm:items-center gap-6">
                <div className="relative w-28 h-28 shrink-0 flex items-center justify-center">
                  <svg viewBox="0 0 108 108" className="w-full h-full -rotate-90" aria-hidden="true">
                    <circle
                      cx="54"
                      cy="54"
                      r={ringRadius}
                      fill="none"
                      stroke="rgba(148,163,184,0.14)"
                      strokeWidth="8"
                    />
                    <circle
                      cx="54"
                      cy="54"
                      r={ringRadius}
                      fill="none"
                      stroke={grade.accentHex}
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={ringCircumference}
                      strokeDashoffset={ringOffset}
                      style={{ transition: 'stroke-dashoffset 250ms ease, stroke 250ms ease' }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span
                      className="font-display text-2xl font-extrabold leading-none"
                      style={{ color: grade.accentHex }}
                    >
                      {grade.grade}
                    </span>
                    <span className="font-mono text-xs text-slate-300 mt-1 tabular-nums">
                      {sohInput}% SoH
                    </span>
                  </div>
                </div>

                <div className="space-y-2 min-w-0">
                  <div className="text-base font-bold text-slate-100">{grade.title}</div>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {grade.useCase}
                  </p>
                  <div className="inline-flex items-center gap-3 font-mono text-xs text-[#22D3EE]">
                    <span>Resale Value Retention: ~{grade.valueRetentionPct}%</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-xs mb-1.5">
                  <label htmlFor="second-life-soh" className="text-slate-300 font-medium">
                    Retired Pack State of Health (SoH %)
                  </label>
                  <span className="font-mono text-[#22E58B] font-semibold tabular-nums">
                    {sohInput}%
                  </span>
                </div>
                <input
                  id="second-life-soh"
                  type="range"
                  min={50}
                  max={92}
                  step={1}
                  value={sohInput}
                  onChange={(e) => setSohInput(Number(e.target.value))}
                  className="w-full telemetry-slider"
                />
              </div>

              <div className="grid grid-cols-3 gap-2 text-[11px] font-mono">
                <button
                  type="button"
                  onClick={() => setSohInput(85)}
                  className="rounded-lg p-2 border border-slate-800 bg-slate-950/60 hover:border-[#22E58B]/50 text-left cursor-pointer"
                >
                  <div className="text-[#22E58B] font-semibold">Grade A (80–90%)</div>
                  <div className="text-slate-400">Grid / Solar Storage</div>
                </button>
                <button
                  type="button"
                  onClick={() => setSohInput(72)}
                  className="rounded-lg p-2 border border-slate-800 bg-slate-950/60 hover:border-[#22D3EE]/50 text-left cursor-pointer"
                >
                  <div className="text-[#22D3EE] font-semibold">Grade B (65–79%)</div>
                  <div className="text-slate-400">Micro-mobility / UPS</div>
                </button>
                <button
                  type="button"
                  onClick={() => setSohInput(58)}
                  className="rounded-lg p-2 border border-slate-800 bg-slate-950/60 hover:border-[#EF4444]/50 text-left cursor-pointer"
                >
                  <div className="text-[#EF4444] font-semibold">Grade C (&lt;65%)</div>
                  <div className="text-slate-400">Recycling</div>
                </button>
              </div>
            </div>
          </div>

          {/* CO2 Offset Counter Card */}
          <div className="lg:col-span-5 glass-panel rounded-xl p-6 flex flex-col justify-between space-y-5">
            <div>
              <div className="flex items-center gap-2">
                <Leaf className="w-4 h-4 text-[#22D3EE]" aria-hidden="true" />
                <h2 className="font-display text-lg font-bold text-slate-100">
                  Estimated CO₂ Offset Counter
                </h2>
              </div>
              <p className="mt-1 text-xs text-slate-400">
                Embodied battery manufacturing carbon avoided via lifespan extension (+{extensionPct}%).
              </p>

              <div className="mt-5 rounded-xl bg-[#05080F]/90 border border-slate-800 p-5">
                <div className="text-xs font-mono text-slate-400">Embodied Carbon Deferred</div>
                <div className="mt-1 text-3xl font-extrabold text-[#22E58B]">
                  <AnimatedCounter value={co2.annualCo2Kg} formatLocale suffix=" kg CO₂" />
                </div>
                <div className="mt-2 text-xs font-mono text-[#22D3EE] tabular-nums">
                  ≈ {co2.treesEquivalent.toLocaleString('en-IN')} mature trees absorbing CO₂ / yr
                </div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <label htmlFor="co2-fleet-slider" className="text-slate-300 font-medium">
                  EV Fleet Size
                </label>
                <span className="font-mono text-slate-100 font-semibold tabular-nums">
                  {fleetSize} packs
                </span>
              </div>
              <input
                id="co2-fleet-slider"
                type="range"
                min={1}
                max={50}
                step={1}
                value={fleetSize}
                onChange={(e) => setFleetSize(Number(e.target.value))}
                className="w-full telemetry-slider"
              />
            </div>
          </div>
        </div>

        {/* Row 2: EV Owner Value Calculator + Compact Prototype BOM */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* EV Owner Value Estimator */}
          <div className="lg:col-span-6 glass-panel rounded-xl p-6 flex flex-col justify-between space-y-5">
            <div>
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4 text-[#22E58B]" aria-hidden="true" />
                <h2 className="font-display text-lg font-bold text-slate-100">
                  EV Owner Value Estimator
                </h2>
              </div>
              <p className="mt-1 text-xs text-slate-400">
                Pack Replacement Cost × Lifespan Extension (5% – 20%)
              </p>

              <div className="mt-5">
                <div className="flex justify-between text-xs mb-1.5">
                  <label htmlFor="pack-cost-slider" className="text-slate-300 font-medium">
                    EV Battery Pack Cost
                  </label>
                  <span className="font-mono text-sm font-bold text-slate-100 tabular-nums">
                    ₹{packCostInr.toLocaleString('en-IN')}
                  </span>
                </div>
                <input
                  id="pack-cost-slider"
                  type="range"
                  min={150000}
                  max={1200000}
                  step={25000}
                  value={packCostInr}
                  onChange={(e) => setPackCostInr(Number(e.target.value))}
                  className="w-full telemetry-slider"
                />
              </div>

              <div className="mt-5">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-300 font-medium">Lifespan Extension</span>
                  <span className="font-mono text-sm font-bold text-[#22E58B] tabular-nums">
                    +{extensionPct}%
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2 mb-3">
                  {EXTENSION_PRESETS.map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setExtensionPct(pct)}
                      className={`py-2 rounded-lg font-mono text-xs font-semibold border transition-colors cursor-pointer ${
                        extensionPct === pct
                          ? 'bg-[#22E58B] text-[#05080F] border-[#22E58B]'
                          : 'bg-slate-950/60 text-slate-200 border-slate-800 hover:border-slate-600'
                      }`}
                    >
                      +{pct}%
                    </button>
                  ))}
                </div>
                <input
                  aria-label="Lifespan extension percentage"
                  type="range"
                  min={5}
                  max={20}
                  step={1}
                  value={extensionPct}
                  onChange={(e) => setExtensionPct(Number(e.target.value))}
                  className="w-full telemetry-slider"
                />
              </div>

              <div className="mt-5 rounded-xl bg-[#22E58B]/10 border border-[#22E58B]/35 p-4">
                <div className="text-xs font-mono uppercase tracking-wider text-[#22E58B]">
                  Estimated Ownership Savings
                </div>
                <div className="mt-1 text-3xl font-extrabold text-slate-100">
                  <AnimatedCounter value={savings.rupeesSaved} prefix="₹" formatLocale />
                </div>
                <div className="mt-1 text-xs font-mono text-slate-300 tabular-nums">
                  +{savings.extraMonths} extra usable months on an 8-year warranty baseline
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-start gap-2 text-xs text-slate-400">
              <Info className="w-4 h-4 text-[#F59E0B] shrink-0 mt-0.5" aria-hidden="true" />
              <span>
                Modeled projection for educational & prototype validation; actual EV savings vary by chemistry and duty cycle.
              </span>
            </div>
          </div>

          {/* Compact Hardware BOM Breakdown */}
          <div className="lg:col-span-6 glass-panel rounded-xl p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-4">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-[#22D3EE]" aria-hidden="true" />
                  <h2 className="font-display text-lg font-bold text-slate-100">
                    Prototype Hardware BOM
                  </h2>
                </div>
                <span className="inline-flex items-center gap-1 font-mono text-xs text-[#22D3EE]">
                  <IndianRupee className="w-3.5 h-3.5" aria-hidden="true" />
                  Bench Unit
                </span>
              </div>

              <div className="divide-y divide-slate-800">
                {PROTOTYPE_BOM.map((row) => (
                  <div
                    key={row.part}
                    className="py-3 flex items-center justify-between gap-4 text-sm"
                  >
                    <div>
                      <div className="font-semibold text-slate-100">{row.part}</div>
                      <div className="text-xs text-slate-400">{row.role}</div>
                    </div>
                    <div className="font-mono text-xs sm:text-sm text-slate-200 tabular-nums whitespace-nowrap">
                      {row.estInr}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between gap-3">
              <span className="text-sm font-semibold text-slate-200">
                TOTAL PROTOTYPE BOM
              </span>
              <span className="font-mono text-lg font-bold text-[#22E58B] tabular-nums">
                ≈ ₹3,200 – ₹6,500
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
