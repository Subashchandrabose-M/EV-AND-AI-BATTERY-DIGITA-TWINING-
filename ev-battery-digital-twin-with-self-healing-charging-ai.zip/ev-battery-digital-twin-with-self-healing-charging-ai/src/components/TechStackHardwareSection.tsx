import React, { useState } from 'react';
import { Code2, Cpu, Database } from 'lucide-react';
import { RevealSection } from './MotionPrimitives';

type CategoryKey = 'all' | 'datasets' | 'hardware' | 'software';

interface StackTile {
  name: string;
  category: Exclude<CategoryKey, 'all'>;
  role: string;
  spec: string;
}

const STACK_TILES: StackTile[] = [
  {
    name: 'NASA Battery Aging Data',
    category: 'datasets',
    role: 'Primary Training Corpus',
    spec: 'PCOE Li-ion charge/discharge & impedance fade trajectories',
  },
  {
    name: 'CALCE Battery Data',
    category: 'datasets',
    role: 'Validation Benchmark',
    spec: 'CS2 & CX2 multi-temperature cycle life datasets',
  },
  {
    name: 'Live Sensor Logs',
    category: 'datasets',
    role: 'Continuous Feedback',
    spec: '1 Hz ESP32 voltage, current & thermal streams stored in Firebase',
  },
  {
    name: 'ESP32',
    category: 'hardware',
    role: 'IoT Edge Controller',
    spec: 'Dual-core Wi-Fi MCU reading sensors & driving PWM/MQTT',
  },
  {
    name: 'Voltage Sensor',
    category: 'hardware',
    role: 'Bus & Cell Potential',
    spec: 'Precision resistor divider / ADC sensing across 3S taps',
  },
  {
    name: 'INA219 Current Sensor',
    category: 'hardware',
    role: 'High-Side Shunt I²C',
    spec: 'Real-time charge & discharge current + power integration',
  },
  {
    name: 'DS18B20 Sensors (×3)',
    category: 'hardware',
    role: 'OneWire Thermal Probes',
    spec: 'Per-series-bank temperature mapping (±0.5°C accuracy)',
  },
  {
    name: 'Li-ion Pack + 3S BMS',
    category: 'hardware',
    role: 'Storage & Hardware Safety',
    spec: '3S Li-ion cells with over-charge, over-discharge & short cutoff',
  },
  {
    name: 'CC/CV Buck + Relay/MOSFET',
    category: 'hardware',
    role: 'Adaptive Charger Stage',
    spec: 'Digitally modulated charging current & emergency disconnect',
  },
  {
    name: 'Python + TensorFlow',
    category: 'software',
    role: 'LSTM & RL Training',
    spec: 'Sequence health forecasting & Q-policy optimization',
  },
  {
    name: 'MQTT Broker',
    category: 'software',
    role: 'Lightweight Telemetry',
    spec: 'Low-latency pub/sub bridge from ESP32 to AI engine',
  },
  {
    name: 'Firebase Realtime DB',
    category: 'software',
    role: 'Cloud State & Logs',
    spec: 'Synced cloud storage for Digital Twin & mobile client',
  },
  {
    name: 'Android Studio',
    category: 'software',
    role: 'Companion Mobile App',
    spec: 'Driver SoC, SoH health score & thermal alert notifications',
  },
];

const CATEGORY_META = {
  datasets: { label: 'Datasets', icon: Database, color: '#22D3EE' },
  hardware: { label: 'Hardware', icon: Cpu, color: '#22E58B' },
  software: { label: 'Software', icon: Code2, color: '#F59E0B' },
};

export const TechStackHardwareSection: React.FC = () => {
  const [filter, setFilter] = useState<CategoryKey>('all');

  const visibleTiles =
    filter === 'all' ? STACK_TILES : STACK_TILES.filter((t) => t.category === filter);

  return (
    <section id="tech-stack" className="py-20 border-b border-white/10 bg-[#090D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-[#22D3EE]">
                08 · Prototype Bill of Materials & Stack
              </p>
              <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
                Tech Stack, Datasets & Hardware
              </h2>
            </div>

            {/* Interactive filter segmented bar */}
            <div className="inline-flex flex-wrap items-center gap-1 p-1 rounded-xl bg-white/[0.04] border border-white/10">
              {(
                [
                  { id: 'all', label: 'All (13)' },
                  { id: 'datasets', label: 'Datasets (3)' },
                  { id: 'hardware', label: 'Hardware (6)' },
                  { id: 'software', label: 'Software (4)' },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilter(tab.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    filter === tab.id
                      ? 'bg-[#22E58B] text-[#070A0F]'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </RevealSection>

        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {visibleTiles.map((tile, idx) => {
            const meta = CATEGORY_META[tile.category];
            const Icon = meta.icon;
            return (
              <RevealSection key={tile.name} delay={(idx % 4) * 0.04}>
                <article className="glass-panel rounded-xl p-5 h-full flex flex-col justify-between hover:border-white/25 transition-colors">
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-mono" style={{ color: meta.color }}>
                        {meta.label}
                      </span>
                      <Icon className="w-4 h-4 text-slate-400" aria-hidden="true" />
                    </div>
                    <h3 className="mt-3 font-display text-base font-bold text-slate-100">
                      {tile.name}
                    </h3>
                    <p className="mt-1 text-xs font-medium text-slate-300">{tile.role}</p>
                    <p className="mt-2 text-xs text-slate-400 leading-relaxed">{tile.spec}</p>
                  </div>
                </article>
              </RevealSection>
            );
          })}
        </div>
      </div>
    </section>
  );
};
