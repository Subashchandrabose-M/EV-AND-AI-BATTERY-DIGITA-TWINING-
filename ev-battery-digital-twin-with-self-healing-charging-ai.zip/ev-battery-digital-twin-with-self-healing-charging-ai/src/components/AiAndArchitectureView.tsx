import React, { useEffect, useMemo, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import {
  Activity,
  ArrowRight,
  BatteryCharging,
  BrainCircuit,
  Cloud,
  Cpu,
  Monitor,
  Play,
  RefreshCw,
  RotateCcw,
  Sliders,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  generateLstmCurveData,
  generateRlRewardCurve,
  RL_LOOP_SAMPLES,
} from '../utils/aiModels';

interface ArchNode {
  id: string;
  label: string;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
  specs: string;
  signal: string;
  accent: string;
}

const ARCH_NODES: ArchNode[] = [
  {
    id: 'pack',
    label: 'Li-ion Pack + 3S BMS',
    sub: '3S3P · Protection',
    icon: BatteryCharging,
    specs: '9× 21700/18650 NMC cells (11.1V nominal, 9.0 Ah) protected by hardware 3S BMS & thermal fuse.',
    signal: 'Power Bus: 9.0V – 12.6V DC · Balance tap lines B1/B2/B3',
    accent: '#22E58B',
  },
  {
    id: 'sensors',
    label: 'Sensors (INA219 / DS18B20)',
    sub: 'I²C + OneWire Probes',
    icon: Activity,
    specs: 'INA219 high-side shunt monitors pack current/voltage; 3× DS18B20 digital probes sit on S1/S2/S3 cell banks.',
    signal: 'INA219: I²C (400 kHz) · DS18B20: 12-bit OneWire (±0.5°C)',
    accent: '#22D3EE',
  },
  {
    id: 'esp32',
    label: 'ESP32',
    sub: 'Edge Telemetry Node',
    icon: Cpu,
    specs: 'Dual-core Wi-Fi MCU samples V, I, T at 1 Hz, runs safety watchdog, and drives PWM gate signals.',
    signal: 'GPIO PWM (25 kHz) · Wi-Fi 802.11n uplink',
    accent: '#22D3EE',
  },
  {
    id: 'cloud',
    label: 'MQTT / Cloud',
    sub: 'Broker + Time-Series DB',
    icon: Cloud,
    specs: 'Publishes compact JSON frames to topic ev/pack/node01/telemetry with QoS 1 buffering.',
    signal: 'Payload: {v, i, t1, t2, t3, soc} @ 1 Hz',
    accent: '#22E58B',
  },
  {
    id: 'ai',
    label: 'LSTM + RL AI Engine',
    sub: 'Simulated NASA/CALCE Core',
    icon: BrainCircuit,
    specs: 'LSTM forecasts SoH & RUL cycles; RL Q-policy outputs optimal charging current setpoint from [V, I, T, SoC].',
    signal: 'Output Action: Target Current I_cmd (3.8A – 17.5A)',
    accent: '#F59E0B',
  },
  {
    id: 'twin',
    label: 'Digital Twin',
    sub: '3D Electro-Thermal View',
    icon: Monitor,
    specs: 'Synchronizes per-cell temperatures, internal resistance, and thermal alerts to the browser cockpit.',
    signal: 'WebGL 3S3P Heatmap + SoH / RUL Telemetry Gauges',
    accent: '#22D3EE',
  },
  {
    id: 'buck',
    label: 'MOSFET/Relay Buck Control',
    sub: 'Closed-Loop Actuator',
    icon: Sliders,
    specs: 'Logic-level MOSFET + synchronous CC/CV buck stage modulates charging current back into the Li-ion pack.',
    signal: 'Feedback Loop → Returns tuned current to Li-ion Pack',
    accent: '#22E58B',
  },
];

export const AiAndArchitectureView: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const fullLstmData = useMemo(() => generateLstmCurveData(), []);
  const rlRewardData = useMemo(() => generateRlRewardCurve(), []);

  const [revealedPoints, setRevealedPoints] = useState<number>(fullLstmData.length);
  const [isDrawing, setIsDrawing] = useState(false);
  const [activeRlIdx, setActiveRlIdx] = useState(0);
  const [activeNodeIdx, setActiveNodeIdx] = useState(0);
  const [inspectedId, setInspectedId] = useState<string>('ai');

  useEffect(() => {
    if (!isDrawing) return;
    if (revealedPoints >= fullLstmData.length) {
      setIsDrawing(false);
      return;
    }
    const timer = window.setTimeout(() => {
      setRevealedPoints((n) => Math.min(fullLstmData.length, n + 1));
    }, 90);
    return () => window.clearTimeout(timer);
  }, [isDrawing, revealedPoints, fullLstmData.length]);

  useEffect(() => {
    if (prefersReducedMotion) return;
    const rlTimer = window.setInterval(() => {
      setActiveRlIdx((i) => (i + 1) % RL_LOOP_SAMPLES.length);
    }, 3200);
    const nodeTimer = window.setInterval(() => {
      setActiveNodeIdx((i) => (i + 1) % ARCH_NODES.length);
    }, 1150);
    return () => {
      window.clearInterval(rlTimer);
      window.clearInterval(nodeTimer);
    };
  }, [prefersReducedMotion]);

  const visibleLstm = fullLstmData.slice(0, revealedPoints);
  const activeSample = RL_LOOP_SAMPLES[activeRlIdx];
  const inspectedNode =
    ARCH_NODES.find((n) => n.id === inspectedId) ?? ARCH_NODES[activeNodeIdx];

  return (
    <section aria-label="AI Engine and Closed-Loop Architecture" className="py-8 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
              Cockpit View 03 · Hybrid Intelligence & Hardware Pipeline
            </p>
            <h1 className="mt-1.5 font-display text-2xl sm:text-3xl font-bold text-slate-100">
              AI Engine & Closed-Loop Architecture
            </h1>
            <p className="mt-1 text-slate-400 text-sm max-w-2xl">
              LSTM State-of-Health forecasting combined with a Reinforcement Learning charging agent and end-to-end hardware telemetry loop.
            </p>
          </div>
          <div className="px-3.5 py-2 rounded-lg bg-[#22D3EE]/10 border border-[#22D3EE]/35 text-xs font-mono text-[#22D3EE] shrink-0">
            Simulated NASA / CALCE-trained behavior running in browser
          </div>
        </div>

        {/* LSTM & RL Visualizer */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left 7 Cols: LSTM SoH & RUL Forecaster */}
          <div className="lg:col-span-7 glass-panel rounded-xl p-6 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-[#22D3EE]/15 border border-[#22D3EE]/35 text-[#22D3EE] flex items-center justify-center">
                    <BrainCircuit className="w-4 h-4" aria-hidden="true" />
                  </div>
                  <div>
                    <h2 className="font-display text-lg font-bold text-slate-100">
                      LSTM SoH & RUL Forecaster
                    </h2>
                    <p className="text-xs text-slate-400">
                      Historical SoH curve & future RUL projection with confidence bounds
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setRevealedPoints(2);
                    setIsDrawing(true);
                  }}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950/60 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 cursor-pointer whitespace-nowrap"
                >
                  {isDrawing ? (
                    <>
                      <RotateCcw className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                      <span>Drawing...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Replay Forecast</span>
                    </>
                  )}
                </button>
              </div>

              <div className="mt-5 h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={visibleLstm}>
                    <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                    <XAxis
                      dataKey="cycle"
                      tick={{ fill: '#64748B', fontSize: 11 }}
                      label={{ value: 'Cycles', position: 'insideBottomRight', offset: -4, fill: '#64748B', fontSize: 10 }}
                    />
                    <YAxis domain={[75, 101]} tick={{ fill: '#94A3B8', fontSize: 11 }} unit="%" width={42} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0B101B',
                        borderColor: 'rgb(30,41,59)',
                        borderRadius: '8px',
                        fontSize: '12px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Area
                      type="monotone"
                      dataKey="upperBound"
                      stroke="none"
                      fill="#22D3EE"
                      fillOpacity={0.12}
                      name="Confidence Upper"
                      isAnimationActive={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="actualSoh"
                      name="NASA/CALCE Actual SoH (%)"
                      stroke="#94A3B8"
                      strokeWidth={2}
                      dot={false}
                      isAnimationActive={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="predictedSoh"
                      name="LSTM Predicted SoH (%)"
                      stroke="#22E58B"
                      strokeWidth={2.5}
                      dot={false}
                      isAnimationActive={false}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-3 gap-3 text-xs font-mono tabular-nums">
              <div>
                <span className="text-slate-400">Validation RMSE</span>
                <div className="text-sm font-bold text-[#22E58B] mt-0.5">0.41% SoH</div>
              </div>
              <div>
                <span className="text-slate-400">Aging Knee Detection</span>
                <div className="text-sm font-bold text-slate-100 mt-0.5">~650 Cycles</div>
              </div>
              <div>
                <span className="text-slate-400">EoL Threshold</span>
                <div className="text-sm font-bold text-[#F59E0B] mt-0.5">80.0% SoH</div>
              </div>
            </div>
          </div>

          {/* Right 5 Cols: RL State -> Action -> Reward & Cumulative Reward Chart */}
          <div className="lg:col-span-5 glass-panel rounded-xl p-6 flex flex-col justify-between space-y-5">
            <div>
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#22E58B]/15 border border-[#22E58B]/35 text-[#22E58B] flex items-center justify-center">
                  <Cpu className="w-4 h-4" aria-hidden="true" />
                </div>
                <div>
                  <h2 className="font-display text-lg font-bold text-slate-100">
                    RL State → Action → Reward
                  </h2>
                  <p className="text-xs text-slate-400">
                    Real-time current throttling policy loop
                  </p>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-1.5" role="tablist" aria-label="RL operating states">
                {RL_LOOP_SAMPLES.map((sample, idx) => (
                  <button
                    key={sample.stepName}
                    type="button"
                    role="tab"
                    aria-selected={idx === activeRlIdx}
                    onClick={() => setActiveRlIdx(idx)}
                    className={`px-2.5 py-1 rounded-md text-xs font-medium cursor-pointer transition-colors whitespace-nowrap ${
                      idx === activeRlIdx
                        ? 'bg-[#22E58B] text-[#05080F] font-semibold'
                        : 'bg-slate-950/60 text-slate-300 border border-slate-800 hover:border-slate-600'
                    }`}
                  >
                    {sample.stepName}
                  </button>
                ))}
              </div>

              <div className="mt-4 space-y-2.5">
                <motion.div
                  key={`state-${activeRlIdx}`}
                  initial={prefersReducedMotion ? undefined : { opacity: 0.6, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="rounded-lg bg-slate-950/60 border border-slate-800 p-3"
                >
                  <div className="text-[11px] font-mono uppercase tracking-wider text-[#22D3EE]">
                    1. State [V, I, Temp, SoC]
                  </div>
                  <div className="text-xs font-mono text-slate-100 mt-1 tabular-nums">
                    {activeSample.state}
                  </div>
                </motion.div>

                <div className="flex justify-center text-slate-500" aria-hidden="true">
                  <ArrowRight className="w-4 h-4 rotate-90" />
                </div>

                <motion.div
                  key={`action-${activeRlIdx}`}
                  initial={prefersReducedMotion ? undefined : { opacity: 0.6, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 }}
                  className="rounded-lg bg-[#22E58B]/10 border border-[#22E58B]/35 p-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#22E58B]">
                      2. Action & Reward
                    </span>
                    <span className="text-xs font-mono font-bold text-[#22E58B]">
                      Reward {activeSample.reward}
                    </span>
                  </div>
                  <div className="text-xs font-mono text-slate-100 mt-1">
                    {activeSample.action}
                  </div>
                  <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                    {activeSample.rationale}
                  </p>
                </motion.div>
              </div>
            </div>

            <div>
              <p className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
                Cumulative Reward Convergence (40 Episodes)
              </p>
              <div className="h-32 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={rlRewardData}>
                    <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                    <XAxis dataKey="episode" tick={{ fill: '#64748B', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#22E58B', fontSize: 10 }} width={32} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#0B101B',
                        borderColor: 'rgb(30,41,59)',
                        borderRadius: '8px',
                        fontSize: '12px',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="reward"
                      name="Cumulative Reward"
                      stroke="#22E58B"
                      strokeWidth={2}
                      dot={false}
                      isAnimationActive={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>

        {/* Animated Closed-Loop System Diagram */}
        <div className="glass-panel rounded-2xl p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-xl font-bold text-slate-100">
                Animated Closed-Loop Hardware-to-Cloud Architecture
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                Hover or click any node to inspect hardware specs and live telemetry signals.
              </p>
            </div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-[#22E58B]/15 border border-[#22E58B]/40 text-xs font-mono font-semibold text-[#22E58B] shrink-0">
              <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>SELF-HEALING LOOP ACTIVE</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-4 items-stretch relative">
            {ARCH_NODES.map((node, index) => {
              const Icon = node.icon;
              const isLit = index === activeNodeIdx;
              const isInspected = node.id === inspectedId;

              return (
                <div key={node.id} className="relative flex flex-col">
                  <button
                    type="button"
                    onMouseEnter={() => setInspectedId(node.id)}
                    onFocus={() => setInspectedId(node.id)}
                    onClick={() => setInspectedId(node.id)}
                    className={`w-full h-full text-left rounded-xl p-4 border transition-all cursor-pointer flex flex-col justify-between ${
                      isInspected
                        ? 'bg-slate-900 border-[#22E58B] shadow-[0_0_24px_rgba(34,229,139,0.2)]'
                        : isLit
                          ? 'bg-slate-900/90 border-[#22D3EE]/60'
                          : 'bg-slate-950/70 border-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <div
                          className="w-9 h-9 rounded-lg flex items-center justify-center border border-slate-800"
                          style={{ backgroundColor: `${node.accent}18`, color: node.accent }}
                        >
                          <Icon className="w-4 h-4" aria-hidden="true" />
                        </div>
                        <span className="font-mono text-[10px] text-slate-500">0{index + 1}</span>
                      </div>

                      <h3 className="mt-3 text-sm font-semibold text-slate-100 leading-snug">
                        {node.label}
                      </h3>
                      <p className="mt-1 text-[11px] font-mono text-slate-400">{node.sub}</p>
                    </div>

                    <div className="mt-3 h-1 w-full rounded-full bg-slate-800 overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: node.accent }}
                        animate={{
                          width: isLit ? '100%' : '20%',
                          opacity: isLit ? 1 : 0.35,
                        }}
                        transition={{ duration: 0.4 }}
                      />
                    </div>
                  </button>

                  {index < ARCH_NODES.length - 1 && (
                    <div
                      aria-hidden="true"
                      className="hidden lg:flex items-center justify-center absolute -right-3 top-1/2 -translate-y-1/2 z-10 w-6 h-6"
                    >
                      <ArrowRight
                        className={`w-4 h-4 transition-colors ${
                          isLit ? 'text-[#22E58B]' : 'text-slate-600'
                        }`}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Return Path & Packet Flow Bar */}
          <div className="pt-4 border-t border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded bg-[#22E58B]/15 border border-[#22E58B]/40 font-mono text-[11px] font-semibold text-[#22E58B]">
                RETURN ACTUATION
              </span>
              <p className="text-xs sm:text-sm text-slate-300">
                MOSFET/Relay Buck Control feeds RL-modulated charging current directly back to the{' '}
                <strong className="text-[#22E58B]">Li-ion Pack</strong>.
              </p>
            </div>

            {!prefersReducedMotion && (
              <div className="w-full md:w-64 h-2 rounded-full bg-slate-800 overflow-hidden relative shrink-0">
                <motion.div
                  className="absolute top-0 bottom-0 w-16 rounded-full bg-gradient-to-r from-transparent via-[#22E58B] to-[#22D3EE]"
                  animate={{ x: ['-4rem', '16rem'] }}
                  transition={{ duration: 2.0, repeat: Infinity, ease: 'linear' }}
                />
              </div>
            )}
          </div>

          {/* Selected Node Spec & Signal Details */}
          <div
            aria-live="polite"
            className="rounded-xl bg-[#05080F]/90 border border-slate-800 p-4 grid grid-cols-1 md:grid-cols-12 gap-3 items-center"
          >
            <div className="md:col-span-8 flex items-start gap-3">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0 mt-1.5"
                style={{ backgroundColor: inspectedNode.accent }}
                aria-hidden="true"
              />
              <div>
                <div className="text-sm font-semibold text-slate-100">{inspectedNode.label}</div>
                <p className="text-xs sm:text-sm text-slate-300 mt-0.5">{inspectedNode.specs}</p>
              </div>
            </div>
            <div className="md:col-span-4 rounded-lg bg-slate-900/80 border border-slate-800 px-3 py-2 font-mono text-[11px] text-[#22D3EE]">
              {inspectedNode.signal}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
