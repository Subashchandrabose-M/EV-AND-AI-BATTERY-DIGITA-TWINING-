import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowDownRight, Cpu, Layers, Radio } from 'lucide-react';

const TYPEWRITER_PHRASES = [
  'Learns cell degradation live.',
  'Adapts current before heat builds.',
  'Extends EV pack lifespan.',
];

const PILLARS = [
  {
    id: 'digital-twin',
    label: 'Digital Twin',
    icon: Layers,
    detail: '3D cell-level thermal & electrochemical mirror updated at 1 Hz.',
    target: '#live-twin',
  },
  {
    id: 'iot',
    label: 'IoT',
    icon: Radio,
    detail: 'ESP32 + INA219 + DS18B20 telemetry streamed over MQTT & Firebase.',
    target: '#architecture',
  },
  {
    id: 'ai',
    label: 'AI',
    icon: Cpu,
    detail: 'LSTM SoH/RUL forecasting paired with RL adaptive charging control.',
    target: '#ai-engine',
  },
];

const FLOATING_CELLS = [
  { id: 'S1-A', v: '3.89 V', t: '29.8°C', color: '#22E58B', x: '5%', y: '18%', delay: 0 },
  { id: 'S2-B', v: '3.86 V', t: '33.4°C', color: '#22D3EE', x: '84%', y: '18%', delay: 0.4 },
  { id: 'S3-C', v: '3.88 V', t: '31.1°C', color: '#22E58B', x: '84%', y: '48%', delay: 0.8 },
];

const TypewriterSubtitle: React.FC<{ reducedMotion: boolean | null }> = ({ reducedMotion }) => {
  const [phraseIdx, setPhraseIdx] = useState(0);
  const [charCount, setCharCount] = useState(TYPEWRITER_PHRASES[0].length);

  useEffect(() => {
    if (reducedMotion) {
      setCharCount(TYPEWRITER_PHRASES[phraseIdx].length);
      return;
    }

    const current = TYPEWRITER_PHRASES[phraseIdx];
    if (charCount < current.length) {
      const t = window.setTimeout(() => setCharCount((c) => c + 1), 45);
      return () => window.clearTimeout(t);
    }

    const pause = window.setTimeout(() => {
      setPhraseIdx((i) => (i + 1) % TYPEWRES_LEN);
      setCharCount(0);
    }, 2600);
    return () => window.clearTimeout(pause);
  }, [charCount, phraseIdx, reducedMotion]);

  const phrase = TYPEWRITER_PHRASES[phraseIdx];
  const typedText = reducedMotion ? phrase : phrase.slice(0, charCount);

  return (
    <div className="mt-4 h-7 flex items-center justify-center">
      <p className="font-mono text-sm sm:text-base text-[#22D3EE] tracking-wide">
        {typedText}
        <span className="inline-block w-2 h-4 ml-1 align-middle bg-[#22E58B] opacity-80" />
      </p>
    </div>
  );
};

export const HeroSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const [activePillar, setActivePillar] = useState('digital-twin');
  const selectedPillarObj = PILLARS.find((p) => p.id === activePillar) ?? PILLARS[0];

  return (
    <section
      id="hero"
      className="relative overflow-hidden bg-telemetry-grid border-b border-white/10 pt-14 pb-16 sm:pt-20 sm:pb-24"
    >
      {/* Ambient radial energy glows */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 w-[780px] h-[420px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(34,229,139,0.16)_0%,rgba(34,211,238,0.08)_45%,transparent_72%)] blur-2xl"
      />

      {/* Floating energy particles & stylized battery cell readouts (desktop decorative layer) */}
      <div aria-hidden="true" className="hidden lg:block pointer-events-none absolute inset-0">
        {FLOATING_CELLS.map((cell) => (
          <motion.div
            key={cell.id}
            animate={
              prefersReducedMotion
                ? undefined
                : { y: [0, -10, 0], opacity: [0.72, 0.96, 0.72] }
            }
            transition={{
              duration: 5.2,
              repeat: Infinity,
              delay: cell.delay,
              ease: 'easeInOut',
            }}
            style={{ left: cell.x, top: cell.y }}
            className="absolute w-32 rounded-xl bg-[#0D131F]/85 border border-white/10 p-3 shadow-lg"
          >
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span>{cell.id}</span>
              <span style={{ color: cell.color }}>{cell.t}</span>
            </div>
            <div className="mt-2 h-2 w-full rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full"
                style={{ width: '74%', backgroundColor: cell.color }}
              />
            </div>
            <div className="mt-1.5 font-mono text-xs font-semibold text-slate-100 tabular-nums">
              {cell.v}
            </div>
          </motion.div>
        ))}

        {/* Glowing energy particles placed clear of cards */}
        {!prefersReducedMotion &&
          [
            { left: '12%', top: '62%' },
            { left: '20%', top: '28%' },
            { left: '76%', top: '34%' },
            { left: '14%', top: '44%' },
          ].map((pos, n) => (
            <motion.span
              key={n}
              className="absolute w-1.5 h-1.5 rounded-full bg-[#22D3EE]"
              style={pos}
              animate={{
                y: [0, -22, 0],
                opacity: [0.15, 0.7, 0.15],
                scale: [0.9, 1.25, 0.9],
              }}
              transition={{
                duration: 3.8 + n * 0.5,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
            />
          ))}
      </div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 text-center">
        {/* Three interactive animated pillar pills (explicitly requested in Hero) */}
        <motion.div
          initial={prefersReducedMotion ? undefined : { opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45 }}
          className="inline-flex flex-wrap items-center justify-center gap-2.5 mb-7"
          role="tablist"
          aria-label="Core project pillars"
        >
          {PILLARS.map((pillar) => {
            const Icon = pillar.icon;
            const active = pillar.id === activePillar;
            return (
              <button
                key={pillar.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActivePillar(pillar.id)}
                className={`inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold tracking-wide transition-all whitespace-nowrap shrink-0 cursor-pointer border ${
                  active
                    ? 'bg-[#22E58B]/15 text-[#22E58B] border-[#22E58B]/50 shadow-[0_0_20px_rgba(34,229,139,0.2)]'
                    : 'bg-white/[0.04] text-slate-300 border-white/10 hover:border-[#22D3EE]/40 hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{pillar.label}</span>
              </button>
            );
          })}
        </motion.div>

        <motion.h1
          initial={prefersReducedMotion ? undefined : { opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.05 }}
          className="font-display font-extrabold tracking-tight text-slate-50 leading-[1.08] max-w-4xl mx-auto text-balance"
          style={{ fontSize: 'clamp(2.25rem, 4.6vw, 3.85rem)' }}
        >
          EV Battery{' '}
          <span className="bg-gradient-to-r from-[#22E58B] via-[#22D3EE] to-[#22E58B] bg-clip-text text-transparent">
            Digital Twin
          </span>{' '}
          with Self-Healing Charging AI
        </motion.h1>

        {/* Typewriter kinetic line */}
        <TypewriterSubtitle reducedMotion={prefersReducedMotion} />

        <motion.p
          initial={prefersReducedMotion ? undefined : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.12 }}
          className="mt-4 text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed"
        >
          A live virtual copy of your battery that learns its health and heals its own charging.
        </motion.p>

        {/* Active pillar concise preview */}
        <div className="mt-4 text-xs sm:text-sm text-slate-400">
          <span>{selectedPillarObj.detail}</span>
          <a
            href={selectedPillarObj.target}
            className="ml-2 text-[#22E58B] hover:underline font-medium whitespace-nowrap"
          >
            Jump to section
          </a>
        </div>

        {/* CTA Buttons */}
        <motion.div
          initial={prefersReducedMotion ? undefined : { opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.18 }}
          className="mt-8 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href="#live-twin"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#22E58B] hover:bg-[#38F29D] text-[#070A0F] font-semibold text-sm transition-transform hover:-translate-y-0.5 shadow-[0_0_28px_rgba(34,229,139,0.28)] whitespace-nowrap shrink-0"
          >
            <span>Launch Live Twin</span>
            <ArrowDownRight className="w-4 h-4" aria-hidden="true" />
          </a>

          <a
            href="#simulator"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-slate-100 border border-white/15 hover:border-[#22D3EE]/50 font-semibold text-sm transition-colors whitespace-nowrap shrink-0"
          >
            <span>See Fast vs AI Charge</span>
          </a>
        </motion.div>

        {/* Team & College Credits at bottom of Hero */}
        <motion.div
          initial={prefersReducedMotion ? undefined : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.28 }}
          className="mt-14 pt-6 border-t border-white/10 max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm text-slate-400"
        >
          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-x-2 gap-y-1">
            <span className="text-slate-200 font-semibold">Team Leader: Subashchandrabose M</span>
            <span aria-hidden="true">·</span>
            <span>Members: Rajaram A, Arun S, Velmurugan P</span>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1">
            <span>Mentor: Kailas</span>
            <span aria-hidden="true">·</span>
            <span className="text-[#22D3EE] font-medium">Arjun College Of Technology</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const TYPEWRES_LEN = TYPEWRITER_PHRASES.length;
