import React from 'react';
import { Flame, Gauge, Pause, Play, RotateCcw, ShieldCheck, TrendingUp } from 'lucide-react';
import {
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import type { useDualChargeSim } from '../hooks/useDualChargeSim';

type DualChargeSimHandle = ReturnType<typeof useDualChargeSim>;

interface FastVsAiSimulatorProps {
  sim: DualChargeSimHandle;
}

const SPEED_OPTIONS = [1, 2, 5];

export const FastVsAiSimulator: React.FC<FastVsAiSimulatorProps> = ({ sim }) => {
  const { latest, summary } = sim;

  return (
    <section aria-label="Fast Charge vs AI Adaptive Charge Simulator" className="py-8 sm:py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Header & Controls */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-[#22D3EE]">
              Cockpit View 02 · Head-to-Head Charge Race
            </p>
            <h1 className="mt-1.5 font-display text-2xl sm:text-3xl font-bold text-slate-100">
              Standard CC/CV Fast Charge vs. Self-Healing AI Charge
            </h1>
            <p className="mt-1 text-slate-400 text-sm max-w-2xl">
              Compare a blind high-current fast charger against the Reinforcement Learning charger from 15% to 95% SoC.
            </p>
          </div>

          <div className="glass-panel rounded-xl px-4 py-2.5 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2">
              {!sim.isRunning ? (
                <button
                  type="button"
                  onClick={sim.start}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#22E58B] hover:bg-[#38F29D] text-[#05080F] text-xs font-semibold cursor-pointer transition-colors whitespace-nowrap shrink-0"
                >
                  <Play className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{sim.isComplete ? 'Replay' : 'Start'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={sim.pause}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#F59E0B] hover:bg-[#FBBF24] text-[#05080F] text-xs font-semibold cursor-pointer transition-colors whitespace-nowrap shrink-0"
                >
                  <Pause className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Pause</span>
                </button>
              )}

              <button
                type="button"
                onClick={sim.reset}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-slate-950/60 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 cursor-pointer transition-colors whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Reset</span>
              </button>
            </div>

            <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800">
              <span className="text-[11px] font-mono text-slate-400 mr-1">Speed:</span>
              {SPEED_OPTIONS.map((spd) => (
                <button
                  key={spd}
                  type="button"
                  onClick={() => sim.setSpeedMultiplier(spd)}
                  aria-pressed={sim.speedMultiplier === spd}
                  className={`px-2.5 py-1 rounded-md font-mono text-xs font-semibold transition-colors cursor-pointer ${
                    sim.speedMultiplier === spd
                      ? 'bg-[#22D3EE] text-[#05080F]'
                      : 'bg-slate-950/60 text-slate-300 border border-slate-800 hover:border-slate-600'
                  }`}
                >
                  {spd}x
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Side-by-side Live Race Tracks */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Track: Standard CC/CV Fast Charger */}
          <div className="glass-panel rounded-xl p-6 border-[#EF4444]/35">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#EF4444]/15 border border-[#EF4444]/35 text-[#EF4444] flex items-center justify-center">
                  <Flame className="w-4 h-4" aria-hidden="true" />
                </div>
                <div>
                  <h2 className="font-display text-lg font-bold text-slate-100">
                    Standard CC/CV Fast Charger
                  </h2>
                  <p className="text-xs text-slate-400">Constant high current regardless of cell heat</p>
                </div>
              </div>
              <span className="font-mono text-xs text-[#F59E0B] tabular-nums">
                T+{latest.minute} min
              </span>
            </div>

            <div className="mt-5">
              <div className="flex justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-400">Charge Progress (SoC)</span>
                <span className="text-slate-100 font-semibold tabular-nums">
                  {latest.fastSoc.toFixed(1)}%
                </span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#F59E0B] to-[#EF4444] transition-all duration-200"
                  style={{ width: `${latest.fastSoc}%` }}
                />
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono tabular-nums">
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">Cell Temp</div>
                <div
                  className={`text-lg font-bold mt-0.5 ${
                    latest.fastTemp > 40 ? 'text-[#EF4444]' : 'text-[#F59E0B]'
                  }`}
                >
                  {latest.fastTemp.toFixed(1)}°C
                </div>
              </div>
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">Current</div>
                <div className="text-lg font-bold text-slate-100 mt-0.5">
                  {latest.fastCurrent.toFixed(1)} A
                </div>
              </div>
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">SoH Fade</div>
                <div className="text-lg font-bold text-[#EF4444] mt-0.5">
                  -{latest.fastHealthLossMpct.toFixed(1)} m%
                </div>
              </div>
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">Pack SoH</div>
                <div className="text-lg font-bold text-slate-200 mt-0.5">
                  {latest.fastSoh.toFixed(3)}%
                </div>
              </div>
            </div>
          </div>

          {/* Right Track: Self-Healing AI Charger */}
          <div className="glass-panel rounded-xl p-6 border-[#22E58B]/35">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-[#22E58B]/15 border border-[#22E58B]/35 text-[#22E58B] flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" aria-hidden="true" />
                </div>
                <div>
                  <h2 className="font-display text-lg font-bold text-slate-100">
                    Self-Healing AI Charger
                  </h2>
                  <p className="text-xs font-mono text-[#22D3EE]">{latest.aiPolicyAction}</p>
                </div>
              </div>
              <span className="font-mono text-xs text-[#22E58B] tabular-nums">
                T+{latest.minute} min
              </span>
            </div>

            <div className="mt-5">
              <div className="flex justify-between text-xs font-mono mb-1.5">
                <span className="text-slate-400">Charge Progress (SoC)</span>
                <span className="text-slate-100 font-semibold tabular-nums">
                  {latest.aiSoc.toFixed(1)}%
                </span>
              </div>
              <div className="h-2.5 w-full rounded-full bg-slate-800 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-[#22D3EE] to-[#22E58B] transition-all duration-200"
                  style={{ width: `${latest.aiSoc}%` }}
                />
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono tabular-nums">
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">Cell Temp</div>
                <div className="text-lg font-bold text-[#22E58B] mt-0.5">
                  {latest.aiTemp.toFixed(1)}°C
                </div>
              </div>
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">RL Current</div>
                <div className="text-lg font-bold text-[#22D3EE] mt-0.5">
                  {latest.aiCurrent.toFixed(1)} A
                </div>
              </div>
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">SoH Fade</div>
                <div className="text-lg font-bold text-[#22E58B] mt-0.5">
                  -{latest.aiHealthLossMpct.toFixed(1)} m%
                </div>
              </div>
              <div className="rounded-lg bg-slate-950/60 border border-slate-800 p-3">
                <div className="text-[11px] text-slate-400">Pack SoH</div>
                <div className="text-lg font-bold text-slate-200 mt-0.5">
                  {latest.aiSoh.toFixed(3)}%
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Overlaid Comparison Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="glass-panel rounded-xl p-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              Pack Temperature (°C)
            </h3>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sim.history}>
                  <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                  <XAxis dataKey="minute" tick={{ fill: '#64748B', fontSize: 10 }} unit="m" />
                  <YAxis domain={[25, 55]} tick={{ fill: '#94A3B8', fontSize: 10 }} width={32} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0B101B',
                      borderColor: 'rgb(30,41,59)',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Line
                    type="monotone"
                    dataKey="fastTemp"
                    name="Fast Charger (°C)"
                    stroke="#EF4444"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="aiTemp"
                    name="AI Charge (°C)"
                    stroke="#22E58B"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass-panel rounded-xl p-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              Charging Current Profile (A)
            </h3>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sim.history}>
                  <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                  <XAxis dataKey="minute" tick={{ fill: '#64748B', fontSize: 10 }} unit="m" />
                  <YAxis domain={[0, 24]} tick={{ fill: '#94A3B8', fontSize: 10 }} width={32} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0B101B',
                      borderColor: 'rgb(30,41,59)',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Line
                    type="monotone"
                    dataKey="fastCurrent"
                    name="Fast Charger (A)"
                    stroke="#F59E0B"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="aiCurrent"
                    name="AI RL Agent (A)"
                    stroke="#22D3EE"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass-panel rounded-xl p-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 mb-3">
              SoH Fade Over Charge (m%)
            </h3>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sim.history}>
                  <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                  <XAxis dataKey="minute" tick={{ fill: '#64748B', fontSize: 10 }} unit="m" />
                  <YAxis tick={{ fill: '#94A3B8', fontSize: 10 }} width={36} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0B101B',
                      borderColor: 'rgb(30,41,59)',
                      borderRadius: '8px',
                      fontSize: '12px',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px' }} />
                  <Line
                    type="monotone"
                    dataKey="fastHealthLossMpct"
                    name="Fast Fade (m%)"
                    stroke="#EF4444"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="aiHealthLossMpct"
                    name="AI Fade (m%)"
                    stroke="#22E58B"
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Live Impact Summary Card */}
        <div className="rounded-xl border border-[#22E58B]/35 bg-gradient-to-r from-[#22E58B]/10 via-slate-900/80 to-[#22D3EE]/10 p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
                {sim.isComplete ? 'Simulation Complete · Impact Summary' : 'Live Impact Summary'}
              </p>
              <h3 className="mt-1 font-display text-xl sm:text-2xl font-bold text-slate-100">
                {sim.history.length <= 1
                  ? 'Press Start to race Standard CC/CV Fast Charging against Self-Healing AI'
                  : `${summary.coolerPeakTempPct}% Cooler Peak Temp & +${summary.extendedLifespanPct}% Extended Battery Lifespan`}
              </h3>
            </div>

            <div className="grid grid-cols-3 gap-4 shrink-0 font-mono tabular-nums">
              <div className="rounded-lg bg-[#05080F]/80 border border-slate-800 px-4 py-3 text-center">
                <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400">
                  <Gauge className="w-3.5 h-3.5 text-[#22D3EE]" aria-hidden="true" />
                  <span>Cooler Peak Temp</span>
                </div>
                <div className="text-xl font-bold text-[#22D3EE] mt-1">
                  {summary.coolerPeakTempPct}%
                </div>
              </div>

              <div className="rounded-lg bg-[#05080F]/80 border border-slate-800 px-4 py-3 text-center">
                <div className="flex items-center justify-center gap-1 text-[11px] text-slate-400">
                  <TrendingUp className="w-3.5 h-3.5 text-[#22E58B]" aria-hidden="true" />
                  <span>Extended Lifespan</span>
                </div>
                <div className="text-xl font-bold text-[#22E58B] mt-1">
                  +{summary.extendedLifespanPct}%
                </div>
              </div>

              <div className="rounded-lg bg-[#05080F]/80 border border-slate-800 px-4 py-3 text-center">
                <div className="text-[11px] text-slate-400">Peak Delta</div>
                <div className="text-xl font-bold text-slate-100 mt-1">
                  -{(summary.fastPeakTemp - summary.aiPeakTemp).toFixed(1)}°C
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
