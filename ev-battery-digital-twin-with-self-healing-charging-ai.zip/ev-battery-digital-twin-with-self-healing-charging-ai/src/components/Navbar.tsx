import React from 'react';
import { Activity, Cpu, Layers, Recycle, Zap } from 'lucide-react';

export type CockpitView = 'twin' | 'simulator' | 'ai-arch' | 'second-life';

interface NavbarProps {
  activeView: CockpitView;
  onSelectView: (view: CockpitView) => void;
  isStreaming: boolean;
}

const VIEW_TABS: Array<{
  id: CockpitView;
  label: string;
  shortLabel: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { id: 'twin', label: 'Live Digital Twin', shortLabel: 'Live Twin', icon: Activity },
  { id: 'simulator', label: 'Fast vs. AI Simulator', shortLabel: 'Fast vs. AI', icon: Zap },
  { id: 'ai-arch', label: 'AI & Architecture', shortLabel: 'AI & Arch', icon: Cpu },
  { id: 'second-life', label: 'Second-Life & ROI', shortLabel: 'Second-Life', icon: Recycle },
];

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  onSelectView,
  isStreaming,
}) => {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-800 bg-[#05080F]/92 backdrop-blur-md w-full overflow-x-hidden">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 sm:h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand & Sense -> Learn -> Heal indicator */}
        <button
          type="button"
          onClick={() => onSelectView('twin')}
          className="flex items-center gap-2 text-left cursor-pointer focus-visible:outline-2 focus-visible:outline-[#22E58B] rounded-lg min-w-0 shrink-0"
        >
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#22E58B]/15 border border-[#22E58B]/40 text-[#22E58B] flex items-center justify-center shrink-0">
            <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4" aria-hidden="true" />
          </div>
          <div>
            <span className="font-display text-sm sm:text-lg font-bold tracking-tight text-slate-100 whitespace-nowrap block leading-none">
              CellPulse<span className="text-[#22E58B]">Twin</span>
            </span>
            <span className="hidden sm:block font-mono text-[10px] tracking-wider text-slate-400 mt-1 whitespace-nowrap">
              SENSE → LEARN → HEAL
            </span>
          </div>
        </button>

        {/* Desktop View Switcher Tabs */}
        <nav
          role="tablist"
          aria-label="Digital Twin Cockpit Views"
          className="hidden lg:flex items-center gap-1 p-1 rounded-xl bg-slate-900/80 border border-slate-800"
        >
          {VIEW_TABS.map((tab) => {
            const Icon = tab.icon;
            const active = activeView === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => onSelectView(tab.id)}
                className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                  active
                    ? 'bg-[#22E58B] text-[#05080F] shadow-[0_0_18px_rgba(34,229,139,0.28)]'
                    : 'text-slate-300 hover:text-white hover:bg-white/[0.05]'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Live MQTT Status Badge */}
        <div
          aria-live="polite"
          className="inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 font-mono text-[10px] sm:text-[11px] whitespace-nowrap shrink-0"
        >
          <span
            className={`w-2 h-2 rounded-full shrink-0 ${
              isStreaming ? 'bg-[#22E58B] animate-pulse' : 'bg-amber-400'
            }`}
            aria-hidden="true"
          />
          <span className={isStreaming ? 'text-[#22E58B]' : 'text-amber-300'}>
            {isStreaming ? 'ESP32_NODE_01 • STREAMING' : 'ESP32_NODE_01 • PAUSED'}
          </span>
        </div>
      </div>

      {/* Tablet / Mobile View Switcher Grid (no horizontal overflow) */}
      <nav
        role="tablist"
        aria-label="Mobile Cockpit Views"
        className="lg:hidden border-t border-slate-800/80 px-3 py-2 grid grid-cols-2 sm:grid-cols-4 gap-1.5"
      >
        {VIEW_TABS.map((tab) => {
          const Icon = tab.icon;
          const active = activeView === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => onSelectView(tab.id)}
              className={`inline-flex items-center justify-center gap-1.5 px-2 py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                active
                  ? 'bg-[#22E58B] text-[#05080F]'
                  : 'bg-slate-900/70 text-slate-300 border border-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span className="truncate">{tab.shortLabel}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
};
