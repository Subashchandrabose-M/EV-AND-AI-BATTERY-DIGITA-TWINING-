import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';

interface RevealSectionProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}

export const RevealSection: React.FC<RevealSectionProps> = ({
  children,
  className = '',
  delay = 0,
}) => {
  const prefersReducedMotion = useReducedMotion();

  if (prefersReducedMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.12 }}
      transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

interface AnimatedCounterProps {
  value: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  formatLocale?: boolean;
  className?: string;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  value,
  decimals = 0,
  prefix = '',
  suffix = '',
  formatLocale = false,
  className = '',
}) => {
  const [displayValue, setDisplayValue] = useState(value);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) {
      setDisplayValue(value);
      return;
    }

    const startValue = displayValue;
    const diff = value - startValue;
    if (Math.abs(diff) < 0.001) {
      setDisplayValue(value);
      return;
    }

    const duration = 480;
    const startTime = performance.now();
    let frameId = 0;

    const tick = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      // Cubic ease out
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayValue(startValue + diff * eased);
      if (progress < 1) {
        frameId = requestAnimationFrame(tick);
      }
    };

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value, prefersReducedMotion]);

  const formatted = formatLocale
    ? Math.round(displayValue).toLocaleString('en-IN')
    : displayValue.toFixed(decimals);

  return (
    <span className={`font-mono tabular-nums ${className}`}>
      {prefix}
      {formatted}
      {suffix}
    </span>
  );
};

interface ArcGaugeProps {
  label: string;
  value: number;
  max: number;
  displayValue: string;
  unit: string;
  sublabel: string;
  colorHex: string;
}

export const ArcGauge: React.FC<ArcGaugeProps> = ({
  label,
  value,
  max,
  displayValue,
  unit,
  sublabel,
  colorHex,
}) => {
  const radius = 44;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.max(0, Math.min(1, value / max));
  const strokeDashoffset = circumference * (1 - pct);

  return (
    <div className="glass-panel rounded-xl p-4 flex items-center gap-4">
      <div className="relative w-24 h-24 shrink-0 flex items-center justify-center">
        <svg viewBox="0 0 104 104" className="w-full h-full -rotate-90" aria-hidden="true">
          <circle
            cx="52"
            cy="52"
            r={radius}
            fill="none"
            stroke="rgba(148, 163, 184, 0.14)"
            strokeWidth="8"
          />
          <circle
            cx="52"
            cy="52"
            r={radius}
            fill="none"
            stroke={colorHex}
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            style={{
              transition: 'stroke-dashoffset 450ms cubic-bezier(0.16, 1, 0.3, 1), stroke 300ms ease',
            }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
          <span className="font-mono tabular-nums text-lg font-bold text-slate-100 leading-none">
            {displayValue}
          </span>
          <span className="font-mono text-[10px] uppercase tracking-wider text-slate-400 mt-1">
            {unit}
          </span>
        </div>
      </div>

      <div className="min-w-0">
        <p className="text-xs font-medium text-slate-400">{label}</p>
        <p className="text-sm font-semibold text-slate-100 mt-0.5 truncate">{sublabel}</p>
      </div>
    </div>
  );
};
