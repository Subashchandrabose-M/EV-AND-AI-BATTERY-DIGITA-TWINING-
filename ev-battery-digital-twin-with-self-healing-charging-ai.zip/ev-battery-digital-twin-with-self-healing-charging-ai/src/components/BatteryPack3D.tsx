import React, { Component, useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Environment, Lightformer, OrbitControls } from '@react-three/drei';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';
import { Flame, RotateCcw } from 'lucide-react';
import { BatteryCellState, computeThermalColorHex } from '../utils/batteryPhysics';
import { detectSoftwareGl } from '../utils/webgl';

interface BatteryPack3DProps {
  cells: BatteryCellState[];
  heatmapMode: boolean;
  onToggleHeatmap: () => void;
  selectedCellId: string;
  onSelectCell: (id: string) => void;
}

class WebGLErrorBoundary extends Component<
  { children: React.ReactNode; fallback: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode; fallback: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(): { hasError: boolean } {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

interface CellMeshProps {
  cell: BatteryCellState;
  position: [number, number, number];
  heatmapMode: boolean;
  isSelected: boolean;
  isHovered: boolean;
  isSoftwareGl: boolean;
  onHover: (id: string | null) => void;
  onSelect: (id: string) => void;
}

const CylindricalCell: React.FC<CellMeshProps> = ({
  cell,
  position,
  heatmapMode,
  isSelected,
  isHovered,
  isSoftwareGl,
  onHover,
  onSelect,
}) => {
  const bodyMatRef = useRef<THREE.MeshStandardMaterial>(null);
  const thermalColor = useMemo(() => computeThermalColorHex(cell.temperature), [cell.temperature]);

  // Emissive glow proportional to temperature
  const heatFactor = Math.max(0, Math.min(1, (cell.temperature - 25) / 19));

  useFrame(({ clock }) => {
    if (isSoftwareGl || !bodyMatRef.current) return;
    const baseEmissive = (heatmapMode ? 0.38 : 0.14) + heatFactor * (heatmapMode ? 0.52 : 0.42);
    const pulse = Math.sin(clock.getElapsedTime() * 3.0 + cell.slotIndex * 0.55) * (0.04 + heatFactor * 0.08);
    const highlightBoost = isSelected || isHovered ? 0.28 : 0;
    bodyMatRef.current.emissiveIntensity = baseEmissive + pulse + highlightBoost;
  });

  const staticEmissive =
    (heatmapMode ? 0.42 : 0.18) + heatFactor * 0.45 + (isSelected || isHovered ? 0.28 : 0);

  return (
    <group position={position}>
      {/* Main cylindrical 21700 Li-ion cell */}
      <mesh
        castShadow={!isSoftwareGl}
        receiveShadow={!isSoftwareGl}
        onPointerOver={(e) => {
          e.stopPropagation();
          onHover(cell.id);
          document.body.style.cursor = 'pointer';
        }}
        onPointerOut={(e) => {
          e.stopPropagation();
          onHover(null);
          document.body.style.cursor = 'auto';
        }}
        onClick={(e) => {
          e.stopPropagation();
          onSelect(cell.id);
        }}
      >
        <cylinderGeometry args={[0.26, 0.26, 1.08, 24]} />
        <meshStandardMaterial
          ref={bodyMatRef}
          color={thermalColor}
          emissive={thermalColor}
          emissiveIntensity={staticEmissive}
          roughness={heatmapMode ? 0.26 : 0.36}
          metalness={heatmapMode ? 0.2 : 0.56}
        />
      </mesh>

      {/* Insulator gasket collar */}
      <mesh position={[0, 0.55, 0]}>
        <cylinderGeometry args={[0.23, 0.23, 0.025, 20]} />
        <meshStandardMaterial color="#CBD5E1" roughness={0.65} metalness={0.1} />
      </mesh>

      {/* Positive nickel terminal */}
      <mesh position={[0, 0.58, 0]}>
        <cylinderGeometry args={[0.115, 0.115, 0.045, 16]} />
        <meshStandardMaterial color="#F1F5F9" roughness={0.2} metalness={0.92} />
      </mesh>

      {/* Selection / hover halo ring */}
      {(isSelected || isHovered) && (
        <mesh position={[0, 0.595, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <ringGeometry args={[0.28, 0.335, 24]} />
          <meshBasicMaterial color={isSelected ? '#22E58B' : '#22D3EE'} side={THREE.DoubleSide} />
        </mesh>
      )}
    </group>
  );
};

interface PackSceneProps {
  cells: BatteryCellState[];
  heatmapMode: boolean;
  selectedCellId: string;
  hoveredCellId: string | null;
  isSoftwareGl: boolean;
  resetSignal: number;
  onHover: (id: string | null) => void;
  onSelect: (id: string) => void;
}

const BatteryPackScene: React.FC<PackSceneProps> = ({
  cells,
  heatmapMode,
  selectedCellId,
  hoveredCellId,
  isSoftwareGl,
  resetSignal,
  onHover,
  onSelect,
}) => {
  const controlsRef = useRef<OrbitControlsImpl>(null);
  const { invalidate, camera, scene, gl } = useThree();

  // Trigger manual redraws when running in demand mode on software WebGL
  useEffect(() => {
    invalidate();
  }, [cells, heatmapMode, selectedCellId, hoveredCellId, invalidate]);

  // Explicit WebGL resource cleanup on unmount
  useEffect(() => {
    return () => {
      document.body.style.cursor = 'auto';
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry?.dispose();
          if (Array.isArray(obj.material)) {
            obj.material.forEach((m) => m.dispose());
          } else {
            obj.material?.dispose();
          }
        }
      });
      gl.dispose();
    };
  }, [scene, gl]);

  useEffect(() => {
    if (resetSignal === 0) return;
    camera.position.set(3.85, 2.75, 4.05);
    if (controlsRef.current) {
      controlsRef.current.target.set(0, -0.05, 0);
      controlsRef.current.update();
    }
    invalidate();
  }, [resetSignal, camera, invalidate]);

  return (
    <>
      <color attach="background" args={['#070B13']} />
      <fog attach="fog" args={['#070B13', 9, 20]} />

      {!isSoftwareGl && (
        <Environment resolution={64} frames={1}>
          <Lightformer
            form="rect"
            intensity={2.1}
            color="#E2E8F0"
            position={[0, 5, 2]}
            rotation={[Math.PI / 2, 0, 0]}
            scale={[8, 4, 1]}
          />
          <Lightformer
            form="rect"
            intensity={1.5}
            color="#22D3EE"
            position={[-5, 2, -3]}
            rotation={[0, Math.PI / 2, 0]}
            scale={[6, 3, 1]}
          />
          <Lightformer
            form="rect"
            intensity={1.3}
            color="#22E58B"
            position={[5, 2, 3]}
            rotation={[0, -Math.PI / 2, 0]}
            scale={[6, 3, 1]}
          />
        </Environment>
      )}

      {/* 3-Point studio lighting */}
      <hemisphereLight args={['#93C5FD', '#1E293B', isSoftwareGl ? 1.1 : 0.58]} />
      <directionalLight
        position={[4.5, 6.5, 4.5]}
        intensity={isSoftwareGl ? 1.85 : 1.45}
        color="#FFF7ED"
        castShadow={!isSoftwareGl}
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0005}
      />
      <directionalLight position={[-4, 3, -4]} intensity={isSoftwareGl ? 0.9 : 0.65} color="#22D3EE" />
      {isSoftwareGl && <directionalLight position={[0, 3, -5]} intensity={0.65} color="#22E58B" />}

      <group position={[0, -0.05, 0]}>
        {/* 1. Lower machined anodized aluminum chassis tray */}
        <mesh position={[0, -0.66, 0]} receiveShadow={!isSoftwareGl}>
          <boxGeometry args={[2.85, 0.14, 2.55]} />
          <meshStandardMaterial color="#1E293B" roughness={0.42} metalness={0.82} />
        </mesh>

        {/* Cooling fins beneath baseplate */}
        {[-0.95, -0.57, -0.19, 0.19, 0.57, 0.95].map((xPos) => (
          <mesh key={xPos} position={[xPos, -0.76, 0]}>
            <boxGeometry args={[0.1, 0.08, 2.4]} />
            <meshStandardMaterial color="#334155" roughness={0.35} metalness={0.85} />
          </mesh>
        ))}

        {/* 2. Composite cell spacer retention frame */}
        <mesh position={[0, -0.34, 0]}>
          <boxGeometry args={[2.55, 0.16, 2.3]} />
          <meshStandardMaterial color="#0F172A" roughness={0.82} metalness={0.12} />
        </mesh>

        {/* 3. 9 Cylindrical 21700 Cells (3S x 3P) */}
        {cells.map((cell) => {
          const bankIdx = cell.bank === 'S1' ? 0 : cell.bank === 'S2' ? 1 : 2;
          const colIdx = cell.slotIndex % 3;
          const x = (colIdx - 1) * 0.78;
          const z = (bankIdx - 1) * 0.74;
          return (
            <CylindricalCell
              key={cell.id}
              cell={cell}
              position={[x, 0, z]}
              heatmapMode={heatmapMode}
              isSelected={cell.id === selectedCellId}
              isHovered={cell.id === hoveredCellId}
              isSoftwareGl={isSoftwareGl}
              onHover={onHover}
              onSelect={onSelect}
            />
          );
        })}

        {/* 4. Copper Series Busbars seated flush on top terminals */}
        {[-0.74, 0, 0.74].map((zPos, i) => (
          <mesh key={i} position={[0, 0.605, zPos]}>
            <boxGeometry args={[1.82, 0.026, 0.16]} />
            <meshStandardMaterial color="#D97706" roughness={0.24} metalness={0.92} />
          </mesh>
        ))}

        {/* Cross-bank copper bridge tabs */}
        <mesh position={[0.83, 0.605, -0.37]}>
          <boxGeometry args={[0.16, 0.03, 0.74]} />
          <meshStandardMaterial color="#D97706" roughness={0.22} metalness={0.92} />
        </mesh>
        <mesh position={[-0.83, 0.605, 0.37]}>
          <boxGeometry args={[0.16, 0.03, 0.74]} />
          <meshStandardMaterial color="#D97706" roughness={0.22} metalness={0.92} />
        </mesh>

        {/* 5. Side BMS Control PCB + MOSFET Heatsink */}
        <group position={[1.52, -0.1, 0]}>
          <mesh>
            <boxGeometry args={[0.15, 0.88, 2.15]} />
            <meshStandardMaterial color="#064E3B" roughness={0.55} metalness={0.2} />
          </mesh>
          <mesh position={[0.09, 0.18, 0]}>
            <boxGeometry args={[0.05, 0.28, 0.38]} />
            <meshStandardMaterial color="#111827" roughness={0.45} metalness={0.35} />
          </mesh>
          <mesh position={[0.09, -0.22, -0.45]}>
            <boxGeometry args={[0.08, 0.24, 0.55]} />
            <meshStandardMaterial color="#94A3B8" roughness={0.25} metalness={0.9} />
          </mesh>
        </group>

        {/* 6. Transparent Busbar Acrylic Enclosure */}
        <group>
          {/* Translucent enclosure shell */}
          <mesh position={[0, 0.05, 0]}>
            <boxGeometry args={[2.76, 1.32, 2.46]} />
            <meshStandardMaterial
              color="#38BDF8"
              transparent
              opacity={0.1}
              roughness={0.18}
              metalness={0.1}
              depthWrite={false}
            />
          </mesh>
          {/* Corner structural aluminum posts */}
          {[
            [-1.34, -1.19],
            [1.34, -1.19],
            [-1.34, 1.19],
            [1.34, 1.19],
          ].map(([px, pz], idx) => (
            <mesh key={idx} position={[px, 0.02, pz]}>
              <boxGeometry args={[0.06, 1.28, 0.06]} />
              <meshStandardMaterial color="#475569" roughness={0.35} metalness={0.85} />
            </mesh>
          ))}
        </group>

        {/* Grounding grid */}
        <gridHelper args={[12, 24, '#1E293B', '#0F172A']} position={[0, -0.84, 0]} />
      </group>

      <OrbitControls
        ref={controlsRef}
        makeDefault
        enablePan={false}
        minDistance={2.8}
        maxDistance={8.5}
        minPolarAngle={0.35}
        maxPolarAngle={Math.PI / 2 - 0.08}
        enableDamping={!isSoftwareGl}
        dampingFactor={0.07}
        onChange={() => invalidate()}
      />
    </>
  );
};

export const BatteryPack3D: React.FC<BatteryPack3DProps> = ({
  cells,
  heatmapMode,
  onToggleHeatmap,
  selectedCellId,
  onSelectCell,
}) => {
  const [hoveredCellId, setHoveredCellId] = useState<string | null>(null);
  const [resetSignal, setResetSignal] = useState(0);
  const isSoftwareGl = useMemo(() => detectSoftwareGl(), []);

  const activeCell =
    cells.find((c) => c.id === hoveredCellId) ||
    cells.find((c) => c.id === selectedCellId) ||
    cells[0];

  const fallback2D = (
    <div className="w-full h-full flex flex-col justify-center items-center p-6 bg-[#070B13] rounded-xl">
      <p className="text-xs font-mono text-slate-400 mb-4">
        3S3P Cell Matrix (2D Thermal Fallback)
      </p>
      <div className="grid grid-cols-3 gap-2.5">
        {cells.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => onSelectCell(c.id)}
            className="p-2.5 rounded-lg border border-slate-700 text-left font-mono text-xs"
            style={{ backgroundColor: `${computeThermalColorHex(c.temperature)}22` }}
          >
            <div className="font-semibold text-slate-100">{c.id}</div>
            <div className="text-slate-300 tabular-nums">{c.temperature.toFixed(1)}°C</div>
            <div className="text-slate-400 tabular-nums">{c.voltage.toFixed(2)}V</div>
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div
      data-testid="battery-3d-viewport"
      className="relative w-full h-[380px] sm:h-[430px] rounded-xl overflow-hidden border border-slate-800 bg-[#070B13]"
    >
      <WebGLErrorBoundary fallback={fallback2D}>
        <Canvas
          frameloop={isSoftwareGl ? 'demand' : 'always'}
          dpr={isSoftwareGl ? 1 : [1, 2]}
          shadows={!isSoftwareGl}
          camera={{ position: [3.85, 2.75, 4.05], fov: 40 }}
          gl={{
            antialias: !isSoftwareGl,
            powerPreference: 'high-performance',
            toneMapping: THREE.ACESFilmicToneMapping,
            toneMappingExposure: 1.08,
          }}
        >
          <BatteryPackScene
            cells={cells}
            heatmapMode={heatmapMode}
            selectedCellId={selectedCellId}
            hoveredCellId={hoveredCellId}
            isSoftwareGl={isSoftwareGl}
            resetSignal={resetSignal}
            onHover={setHoveredCellId}
            onSelect={onSelectCell}
          />
        </Canvas>
      </WebGLErrorBoundary>

      {/* Top HUD Bar: stacks cleanly on mobile, splits left/right on sm+ */}
      <div className="pointer-events-none absolute top-2.5 inset-x-2.5 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2">
        <div className="px-2.5 py-1.5 rounded-lg bg-[#080E1A]/92 border border-slate-800 text-[10px] sm:text-[11px] font-mono text-slate-300 flex items-center gap-2.5 self-start">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#22E58B]" aria-hidden="true" />
            25°C Cool
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#F59E0B]" aria-hidden="true" />
            35°C Warm
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-[#EF4444]" aria-hidden="true" />
            40°C+ Alert
          </span>
        </div>

        {activeCell && (
          <div
            aria-live="polite"
            className="px-2.5 py-1.5 rounded-lg bg-[#080E1A]/94 border border-slate-800 text-[11px] sm:text-xs font-mono self-start sm:self-auto"
          >
            <div className="flex items-center justify-between gap-3">
              <span className="font-semibold text-[#22D3EE]">{activeCell.label}</span>
              <span
                className={
                  activeCell.status === 'Thermal Alert'
                    ? 'text-[#EF4444]'
                    : activeCell.status === 'Elevated'
                      ? 'text-[#F59E0B]'
                      : 'text-[#22E58B]'
                }
              >
                {activeCell.status}
              </span>
            </div>
            <div className="mt-0.5 flex items-center gap-2 text-slate-200 tabular-nums">
              <span>{activeCell.voltage.toFixed(3)} V</span>
              <span aria-hidden="true">·</span>
              <span>{activeCell.temperature.toFixed(1)} °C</span>
              <span aria-hidden="true">·</span>
              <span>{activeCell.internalResistanceMohm} mΩ</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom control dock */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 max-w-[calc(100%-1.5rem)] flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-[#080E1A]/94 border border-slate-800">
        <button
          type="button"
          onClick={onToggleHeatmap}
          aria-pressed={heatmapMode}
          className={`inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-[11px] sm:text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            heatmapMode
              ? 'bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40'
              : 'bg-white/[0.05] text-slate-200 border border-slate-700 hover:bg-white/[0.1]'
          }`}
        >
          <Flame className="w-3.5 h-3.5" aria-hidden="true" />
          <span>{heatmapMode ? 'Thermal Heatmap: ON' : '3D Thermal Heatmap'}</span>
        </button>

        <button
          type="button"
          onClick={() => setResetSignal((n) => n + 1)}
          className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-slate-700 text-[11px] sm:text-xs font-medium text-slate-200 whitespace-nowrap shrink-0 cursor-pointer transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
          <span>Reset View</span>
        </button>

        <span className="hidden md:inline text-[11px] text-slate-400 pl-1 whitespace-nowrap">
          Drag to orbit · Click cell to inspect
        </span>
      </div>
    </div>
  );
};
