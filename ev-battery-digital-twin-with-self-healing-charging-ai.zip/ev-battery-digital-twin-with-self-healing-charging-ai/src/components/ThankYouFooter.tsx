import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowUp } from 'lucide-react';

export const ThankYouFooter: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <footer
      id="thank-you"
      className="relative overflow-hidden py-16 sm:py-20 bg-[#070A0F]"
    >
      {/* Subtle animated gradient backdrop */}
      {!prefersReducedMotion && (
        <motion.div
          aria-hidden="true"
          animate={{ opacity: [0.35, 0.6, 0.35] }}
          transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
          className="pointer-events-none absolute inset-x-0 bottom-0 h-64 bg-[radial-gradient(ellipse_at_bottom,rgba(34,229,139,0.14)_0%,rgba(34,211,238,0.06)_45%,transparent_75%)]"
        />
      )}

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 text-center">
        <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
          Arjun College Of Technology · Capstone Presentation
        </p>
        <h2 className="mt-3 font-display text-3xl sm:text-4xl font-extrabold text-slate-100">
          Thank You — Questions Are Welcome
        </h2>
        <p className="mt-3 text-sm sm:text-base text-slate-400 max-w-xl mx-auto">
          EV Battery Digital Twin with Self-Healing Charging AI · Sense · Learn · Heal
        </p>

        {/* Full Team & Mentor Credits */}
        <div className="mt-8 inline-grid grid-cols-1 sm:grid-cols-3 gap-4 text-left glass-panel rounded-xl p-5 max-w-3xl w-full">
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[#22D3EE]">
              Team Leader
            </div>
            <div className="mt-1 text-sm font-semibold text-slate-100">
              Subashchandrabose M
            </div>
          </div>
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[#22E58B]">
              Team Members
            </div>
            <div className="mt-1 text-sm font-medium text-slate-200">
              Rajaram A · Arun S · Velmurugan P
            </div>
          </div>
          <div>
            <div className="font-mono text-[11px] uppercase tracking-wider text-[#F59E0B]">
              Project Mentor & Institution
            </div>
            <div className="mt-1 text-sm font-medium text-slate-200">
              Kailas · Arjun College Of Technology
            </div>
          </div>
        </div>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-4 text-xs text-slate-500">
          <span>CellPulse Twin Capstone Demo</span>
          <span aria-hidden="true">·</span>
          <a
            href="#hero"
            className="inline-flex items-center gap-1.5 text-slate-300 hover:text-[#22E58B] transition-colors"
          >
            <ArrowUp className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Back to Top</span>
          </a>
        </div>
      </div>
    </footer>
  );
};
