import React, { useEffect, useRef, useState } from 'react';
import { Bot, MessageSquare, Send, X } from 'lucide-react';
import { answerBatteryQuestionFromKnowledge } from '../utils/assistantKnowledge';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
}

const QUICK_PROMPTS = [
  'Explain the battery physics',
  'How does LSTM forecasting work?',
  'How does the RL reward function work?',
  'Describe the hardware wiring',
];

export const BatteryAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: 'Hello! I am Battery AI Copilot. Ask me about our 3S3P battery physics, LSTM forecasting, RL reward function, or ESP32 hardware wiring.',
    },
  ]);

  const inputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
    }
  }, [messages, isOpen]);

  const sendQuestion = (rawText: string) => {
    const question = rawText.trim();
    if (!question) return;

    const reply = answerBatteryQuestionFromKnowledge(question);
    const ts = Date.now();
    setMessages((prev) => [
      ...prev,
      { id: `u-${ts}`, role: 'user', text: question },
      { id: `a-${ts}`, role: 'assistant', text: reply },
    ]);
    setInput('');
  };

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen && (
        <div
          role="dialog"
          aria-label="Battery AI Copilot"
          className="mb-3 w-[min(360px,calc(100vw-2rem))] rounded-2xl bg-[#0B101B] border border-slate-800 shadow-[0_24px_60px_rgba(0,0,0,0.85)] overflow-hidden flex flex-col"
        >
          {/* Header */}
          <div className="px-4 py-3 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-[#22E58B]/15 border border-[#22E58B]/40 text-[#22E58B] flex items-center justify-center">
                <Bot className="w-4 h-4" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-slate-100 leading-none">
                  Battery AI Copilot
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Built-in Technical Assistant
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              aria-label="Close Battery AI Copilot"
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="p-3.5 h-64 overflow-y-auto space-y-3 text-xs leading-relaxed">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-xl px-3.5 py-2.5 whitespace-pre-line ${
                    m.role === 'user'
                      ? 'bg-[#22E58B] text-[#05080F] font-medium'
                      : 'bg-slate-900 border border-slate-800 text-slate-200'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Quick prompts */}
          <div className="px-3.5 pb-2 flex flex-wrap gap-1.5">
            {QUICK_PROMPTS.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => sendQuestion(q)}
                className="px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-800 border border-slate-800 text-[11px] text-slate-300 cursor-pointer transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              sendQuestion(input);
            }}
            className="p-3 border-t border-slate-800 flex items-center gap-2 bg-[#070B13]"
          >
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about physics, LSTM, RL, wiring..."
              aria-label="Ask Battery AI Copilot"
              className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#22E58B]"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              aria-label="Send question"
              className="p-2 rounded-lg bg-[#22E58B] disabled:opacity-40 text-[#05080F] cursor-pointer hover:bg-[#38F29D] transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      <button
        type="button"
        onClick={() => {
          setIsOpen((prev) => {
            const next = !prev;
            if (next) {
              window.setTimeout(() => inputRef.current?.focus(), 60);
            }
            return next;
          });
        }}
        className="inline-flex items-center gap-2 px-4 py-3 rounded-full bg-[#22E58B] hover:bg-[#38F29D] text-[#05080F] font-semibold text-xs sm:text-sm shadow-[0_8px_30px_rgba(34,229,139,0.35)] cursor-pointer transition-transform hover:-translate-y-0.5 whitespace-nowrap"
      >
        <MessageSquare className="w-4 h-4" aria-hidden="true" />
        <span>Battery AI Copilot</span>
      </button>
    </div>
  );
};
