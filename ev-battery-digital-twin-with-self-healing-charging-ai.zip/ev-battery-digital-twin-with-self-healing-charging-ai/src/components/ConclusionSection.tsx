import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { CheckCircle2, Compass, Cpu, Flame, ShieldAlert, Sun } from 'lucide-react';
import { RevealSection } from './MotionPrimitives';

const SAFETY_TIPS = [
  {
    title: 'Safety First: BMS, Fuse & Thermal Cut-Off',
    detail:
      'Always wire a hardware 3S BMS, inline over-current fuse, and software/relay temperature cut-off above 45°C. Never charge Li-ion cells unattended.',
    icon: ShieldAlert,
    accent: '#EF4444',
  },
  {
    title: 'Start with Open Aging Datasets',
    detail:
      'Pre-train LSTM health estimators on NASA PCOE and CALCE CS2/CX2 datasets before fine-tuning with local ESP32 bench cycles.',
    icon: Compass,
    accent: '#22D3EE',
  },
  {
    title: 'Use Genuine Matched Cells',
    detail:
      'Source grade-A genuine 18650/21700 cells with matched internal resistance so 3S bank balance and thermal baselines stay authentic.',
    icon: Flame,
    accent: '#22E58B',
  },
];

const FUTURE_SCOPE = [
  {
    title: 'TinyML Directly on ESP32',
    detail:
      'Quantize the LSTM + RL policy into TensorFlow Lite Micro for sub-millisecond offline inference without cloud latency.',
    icon: Cpu,
  },
  {
    title: 'Real EV Integration via CAN Bus',
    detail:
      'Bridge the digital twin with production vehicle BMS frames over CAN / OBD-II for live on-road SoH diagnostics.',
    icon: CheckCircle2,
  },
  {
    title: 'Second-Life Packs + Solar Microgrids',
    detail:
      'Route Grade A/B retired EV modules into AI-managed solar battery banks with automated thermal balancing.',
    icon: Sun,
  },
];

const NEXT_STEPS = [
  { step: '01', title: 'Build Prototype', desc: 'Assemble 3S pack, BMS, ESP32 & sensors' },
  { step: '02', title: 'Collect Data', desc: 'Log V, I & T cycles over MQTT / Firebase' },
  { step: '03', title: 'Train Model', desc: 'Calibrate LSTM SoH & RL current policy' },
  { step: '04', title: 'Demo Fast vs AI', desc: 'Measure cooler temp & lower degradation' },
];

export const ConclusionSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    if (prefersReducedMotion) return;
    const timer = window.setInterval(() => {
      setActiveStep((s) => (s + 1) % NEXT_STEPS.length);
    }, 2200);
    return () => window.clearInterval(timer);
  }, [prefersReducedMotion]);

  return (
    <section id="conclusion" className="py-20 border-b border-white/10 bg-[#090D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-widest text-[#22D3EE]">
              10 · Engineering Roadmap & Lab Safety
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
              Prototype Guidelines & Future Scope
            </h2>
          </div>
        </RevealSection>

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Prototype Tips */}
          <RevealSection>
            <div className="glass-panel rounded-xl p-6 h-full">
              <h3 className="font-display text-lg font-bold text-slate-100 mb-4">
                Bench Prototype Safety & Best Practices
              </h3>
              <div className="space-y-4">
                {SAFETY_TIPS.map((tip) => {
                  const Icon = tip.icon;
                  return (
                    <div
                      key={tip.title}
                      className="rounded-xl bg-white/[0.03] border border-white/10 p-4 flex items-start gap-3.5"
                    >
                      <div
                        className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 border border-white/10"
                        style={{ backgroundColor: `${tip.accent}18`, color: tip.accent }}
                      >
                        <Icon className="w-4 h-4" aria-hidden="true" />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-slate-100">{tip.title}</h4>
                        <p className="mt-1 text-xs text-slate-400 leading-relaxed">{tip.detail}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </RevealSection>

          {/* Future Scope */}
          <RevealSection delay={0.08}>
            <div className="glass-panel rounded-xl p-6 h-full">
              <h3 className="font-display text-lg font-bold text-slate-100 mb-4">
                Future Scope & Scaling Path
              </h3>
              <div className="space-y-4">
                {FUTURE_SCOPE.map((item) => {
                  const Icon = item.icon;
                  return (
                    <div
                      key={item.title}
                      className="rounded-xl bg-white/[0.03] border border-white/10 p-4 flex items-start gap-3.5"
                    >
                      <div className="w-9 h-9 rounded-lg bg-[#22D3EE]/15 border border-[#22D3EE]/30 text-[#22D3EE] flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4" aria-hidden="true" />
                      </div>
                      <div>
                        <h4 className="text-sm font-semibold text-slate-100">{item.title}</h4>
                        <p className="mt-1 text-xs text-slate-400 leading-relaxed">{item.detail}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </RevealSection>
        </div>

        {/* NEXT STEP Animated Stepper */}
        <RevealSection delay={0.14}>
          <div className="mt-8 glass-panel rounded-xl p-6">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
              <span className="font-mono text-xs font-semibold uppercase tracking-widest text-[#22E58B]">
                Next Step Execution Roadmap
              </span>
              <span className="font-mono text-xs text-slate-400">
                Click any phase to inspect
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {NEXT_STEPS.map((st, idx) => {
                const isActive = idx === activeStep;
                return (
                  <button
                    key={st.step}
                    type="button"
                    onClick={() => setActiveStep(idx)}
                    className={`text-left rounded-xl p-4 border transition-all cursor-pointer relative overflow-hidden ${
                      isActive
                        ? 'bg-[#22E58B]/12 border-[#22E58B]/60'
                        : 'bg-white/[0.02] border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={`font-mono text-xs font-bold ${
                          isActive ? 'text-[#22E58B]' : 'text-slate-500'
                        }`}
                      >
                        STEP {st.step}
                      </span>
                      {isActive && !prefersReducedMotion && (
                        <motion.span
                          layoutId="next-step-indicator"
                          className="w-2 h-2 rounded-full bg-[#22E58B]"
                        />
                      )}
                    </div>
                    <h4 className="mt-2 font-display text-base font-bold text-slate-100">
                      {st.title}
                    </h4>
                    <p className="mt-1 text-xs text-slate-400">{st.desc}</p>
                  </button>
                );
              })}
            </div>
          </div>
        </RevealSection>
      </div>
    </section>
  );
};
