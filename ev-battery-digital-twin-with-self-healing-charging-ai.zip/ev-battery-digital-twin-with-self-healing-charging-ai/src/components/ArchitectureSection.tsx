import React, { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import {
  Activity,
  ArrowRight,
  BatteryCharging,
  BrainCircuit,
  Cloud,
  Cpu,
  MonitorSmartphone,
  RefreshCw,
  Sliders,
} from 'lucide-react';
import { RevealSection } from './MotionPrimitives';

interface ArchNode {
  id: string;
  label: string;
  sub: string;
  icon: React.ComponentType<{ className?: string }>;
  tooltip: string;
  accent: string;
}

const ARCH_NODES: ArchNode[] = [
  {
    id: 'pack',
    label: 'Li-ion Pack + BMS',
    sub: '3S4P Cells · Protection',
    icon: BatteryCharging,
    tooltip: '3-Series 4-Parallel Li-ion cell pack safeguarded by hardware 3S BMS and fuse cutoff.',
    accent: '#22E58B',
  },
  {
    id: 'sensors',
    label: 'Sensors (V, I, T)',
    sub: 'INA219 · 3× DS18B20',
    icon: Activity,
    tooltip: 'Measures bus voltage, pack current via INA219, and per-bank temperatures via DS18B20 probes.',
    accent: '#22D3EE',
  },
  {
    id: 'esp32',
    label: 'ESP32 Edge Node',
    sub: '1 Hz Sampling · Wi-Fi',
    icon: Cpu,
    tooltip: 'Samples ADC & OneWire sensors every second and publishes JSON telemetry over MQTT.',
    accent: '#22D3EE',
  },
  {
    id: 'cloud',
    label: 'Firebase Cloud (MQTT)',
    sub: 'Realtime Sync · Logs',
    icon: Cloud,
    tooltip: 'Ingests live MQTT packets into Firebase Realtime DB for historical aging logs & remote sync.',
    accent: '#22E58B',
  },
  {
    id: 'ai',
    label: 'AI Engine (LSTM + RL)',
    sub: 'SoH/RUL + Current Policy',
    icon: BrainCircuit,
    tooltip: 'LSTM estimates SoH & RUL; RL policy computes the safest optimal charging current setpoint.',
    accent: '#F59E0B',
  },
  {
    id: 'twin',
    label: 'Digital Twin + Android',
    sub: '3D View · Mobile Alerts',
    icon: MonitorSmartphone,
    tooltip: 'Renders the live 3D thermal cell model in browser and pushes charge alerts to Android.',
    accent: '#22D3EE',
  },
  {
    id: 'charger',
    label: 'Adaptive Charger',
    sub: 'CC/CV Buck · Relay/MOSFET',
    icon: Sliders,
    tooltip: 'Adjusts PWM/buck setpoint and MOSFET gate duty cycle, closing the self-healing loop back to the pack.',
    accent: '#22E58B',
  },
];

export const ArchitectureSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const [activeIndex, setActiveIndex] = useState(0);
  const [inspectedId, setInspectedId] = useState<string>('ai');

  useEffect(() => {
    if (prefersReducedMotion) return;
    const timer = window.setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % ARCH_NODES.length);
    }, 1150);
    return () => window.clearInterval(timer);
  }, [prefersReducedMotion]);

  const inspectedNode =
    ARCH_NODES.find((n) => n.id === inspectedId) ?? ARCH_NODES[activeIndex];

  return (
    <section id="architecture" className="py-20 border-b border-white/10 bg-[#090D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
            <div>
              <p className="font-mono text-xs uppercase tracking-widest text-[#22D3EE]">
                06 · End-to-End Signal Flow
              </p>
              <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
                System Architecture & Self-Healing Loop
              </h2>
              <p className="mt-2 text-slate-400 text-sm sm:text-base max-w-2xl">
                Hover or click any hardware/cloud node to inspect its role in the closed-loop control pipeline.
              </p>
            </div>

            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#22E58B]/12 border border-[#22E58B]/35 text-xs font-mono font-semibold text-[#22E58B] shrink-0">
              <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>SELF-HEALING LOOP ACTIVE</span>
            </div>
          </div>
        </RevealSection>

        {/* Pipeline Nodes Grid with Animated Data Packets */}
        <div className="mt-10 relative glass-panel rounded-2xl p-6 sm:p-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-4 items-stretch relative">
            {ARCH_NODES.map((node, index) => {
              const Icon = node.icon;
              const isLit = index === activeIndex;
              const isInspected = node.id === inspectedId;

              return (
                <div key={node.id} className="relative flex flex-col">
                  <button
                    type="button"
                    onMouseEnter={() => setInspectedId(node.id)}
                    onFocus={() => setInspectedId(node.id)}
                    onClick={() => setInspectedId(node.id)}
                    className={`w-full h-full text-left rounded-xl p-4 border transition-all cursor-pointer flex flex-col justify-between ${
                      isInspected
                        ? 'bg-[#111A2B] border-[#22E58B] shadow-[0_0_24px_rgba(34,229,139,0.2)]'
                        : isLit
                          ? 'bg-[#0F1726] border-[#22D3EE]/60'
                          : 'bg-[#0B1019] border-white/10 hover:border-white/25'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <div
                          className="w-9 h-9 rounded-lg flex items-center justify-center border border-white/10"
                          style={{ backgroundColor: `${node.accent}18`, color: node.accent }}
                        >
                          <Icon className="w-4 h-4" aria-hidden="true" />
                        </div>
                        <span className="font-mono text-[10px] text-slate-500">
                          0{index + 1}
                        </span>
                      </div>

                      <h3 className="mt-3 text-sm font-semibold text-slate-100 leading-snug">
                        {node.label}
                      </h3>
                      <p className="mt-1 text-[11px] font-mono text-slate-400">{node.sub}</p>
                    </div>

                    {/* Packet progress bar along bottom edge */}
                    <div className="mt-3 h-1 w-full rounded-full bg-white/5 overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: node.accent }}
                        animate={{
                          width: isLit ? '100%' : '20%',
                          opacity: isLit ? 1 : 0.3,
                        }}
                        transition={{ duration: 0.45 }}
                      />
                    </div>
                  </button>

                  {/* Connector arrow with animated moving packet on desktop */}
                  {index < ARCH_NODES.length - 1 && (
                    <div
                      aria-hidden="true"
                      className="hidden lg:flex items-center justify-center absolute -right-3 top-1/2 -translate-y-1/2 z-10 w-6 h-6"
                    >
                      <ArrowRight
                        className={`w-4 h-4 transition-colors ${
                          isLit ? 'text-[#22E58B]' : 'text-slate-600'
                        }`}
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Highlighted Return Feedback Path (Adaptive Charger -> Li-ion Pack) */}
          <div className="mt-6 pt-5 border-t border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="px-2.5 py-1 rounded bg-[#22E58B]/15 border border-[#22E58B]/40 font-mono text-[11px] font-semibold text-[#22E58B]">
                CLOSED FEEDBACK
              </span>
              <p className="text-xs sm:text-sm text-slate-300">
                Adaptive Charger (Relay / MOSFET + Buck) feeds tuned current back into the Li-ion Pack, completing the{' '}
                <strong className="text-[#22E58B]">Self-Healing Loop</strong>.
              </p>
            </div>

            {!prefersReducedMotion && (
              <div className="w-full md:w-64 h-2 rounded-full bg-white/5 overflow-hidden relative shrink-0">
                <motion.div
                  className="absolute top-0 bottom-0 w-16 rounded-full bg-gradient-to-r from-transparent via-[#22E58B] to-[#22D3EE]"
                  animate={{ x: ['-4rem', '16rem'] }}
                  transition={{ duration: 2.2, repeat: Infinity, ease: 'linear' }}
                />
              </div>
            )}
          </div>

          {/* Interactive Node Tooltip / Inspector Banner */}
          <div
            aria-live="polite"
            className="mt-5 rounded-xl bg-[#070A0F]/80 border border-white/10 px-4 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
          >
            <div className="flex items-center gap-2.5">
              <span
                className="w-2.5 h-2.5 rounded-full shrink-0"
                style={{ backgroundColor: inspectedNode.accent }}
                aria-hidden="true"
              />
              <span className="text-sm font-semibold text-slate-100">
                {inspectedNode.label}:
              </span>
              <span className="text-sm text-slate-300">{inspectedNode.tooltip}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
