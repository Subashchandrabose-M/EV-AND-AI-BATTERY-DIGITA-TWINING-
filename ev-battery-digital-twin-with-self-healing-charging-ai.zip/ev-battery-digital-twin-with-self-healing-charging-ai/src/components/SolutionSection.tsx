import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { Activity, ArrowRight, BrainCircuit, ShieldCheck } from 'lucide-react';
import { RevealSection } from './MotionPrimitives';

const PILLAR_FLOW = [
  {
    step: '01',
    title: 'Sense',
    subtitle: 'IoT Telemetry & 3D Mirror',
    icon: Activity,
    accent: '#22D3EE',
    points: [
      'ESP32 reads pack voltage, INA219 current & 3× DS18B20 cell temperatures every second.',
      'Streams packets over MQTT to Firebase & syncs the interactive 3D battery twin.',
    ],
  },
  {
    step: '02',
    title: 'Learn',
    subtitle: 'LSTM Health Forecasting',
    icon: BrainCircuit,
    accent: '#22E58B',
    points: [
      'LSTM sequence model trained on NASA & CALCE aging curves tracks subtle impedance rise.',
      'Continuously forecasts State of Health (SoH %) and Remaining Useful Life (cycles).',
    ],
  },
  {
    step: '03',
    title: 'Heal',
    subtitle: 'RL Adaptive Charging',
    icon: ShieldCheck,
    accent: '#F59E0B',
    points: [
      'Reinforcement Learning agent tunes current and voltage taper in real time.',
      'Curtails Joule heating (I²R) before thermal stress accelerates capacity fade.',
    ],
  },
];

export const SolutionSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section id="solution" className="py-20 border-b border-white/10 bg-[#090D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="max-w-2xl">
            <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
              02 · Core Closed-Loop Architecture
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
              Sense · Learn · Heal
            </h2>
            <p className="mt-3 text-slate-400 text-base">
              Three tightly coupled stages transform a passive charger into a protective, self-healing digital twin.
            </p>
          </div>
        </RevealSection>

        <div className="mt-12 grid grid-cols-1 lg:grid-cols-[1fr_auto_1fr_auto_1fr] items-stretch gap-4 lg:gap-3">
          {PILLAR_FLOW.map((card, index) => {
            const Icon = card.icon;
            return (
              <React.Fragment key={card.title}>
                <RevealSection delay={index * 0.08} className="h-full">
                  <article className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between hover:border-white/20 transition-colors">
                    <div>
                      <div className="flex items-center justify-between">
                        <span
                          className="font-mono text-xs font-semibold tracking-wider"
                          style={{ color: card.accent }}
                        >
                          STAGE {card.step}
                        </span>
                        <div
                          className="w-10 h-10 rounded-lg flex items-center justify-center border border-white/10"
                          style={{ backgroundColor: `${card.accent}18`, color: card.accent }}
                        >
                          <Icon className="w-5 h-5" aria-hidden="true" />
                        </div>
                      </div>

                      <h3 className="mt-5 font-display text-2xl font-bold text-slate-100">
                        {card.title}
                      </h3>
                      <p className="text-xs font-mono text-slate-400 mt-1">{card.subtitle}</p>

                      <ul className="mt-5 space-y-3 text-sm text-slate-300 leading-relaxed">
                        {card.points.map((pt) => (
                          <li key={pt} className="flex items-start gap-2.5">
                            <span
                              className="w-1.5 h-1.5 rounded-full mt-2 shrink-0"
                              style={{ backgroundColor: card.accent }}
                              aria-hidden="true"
                            />
                            <span>{pt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </article>
                </RevealSection>

                {index < PILLAR_FLOW.length - 1 && (
                  <div
                    aria-hidden="true"
                    className="hidden lg:flex items-center justify-center px-1"
                  >
                    <motion.div
                      animate={
                        prefersReducedMotion
                          ? undefined
                          : { x: [0, 5, 0], opacity: [0.55, 1, 0.55] }
                      }
                      transition={{
                        duration: 1.6,
                        repeat: Infinity,
                        delay: index * 0.35,
                        ease: 'easeInOut',
                      }}
                      className="w-9 h-9 rounded-full bg-white/[0.04] border border-white/10 flex items-center justify-center text-[#22E58B]"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </motion.div>
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>
    </section>
  );
};
