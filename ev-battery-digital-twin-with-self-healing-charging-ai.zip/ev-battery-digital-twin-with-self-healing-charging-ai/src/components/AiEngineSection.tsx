import React, { useEffect, useMemo, useState } from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { ArrowRight, BrainCircuit, Cpu, Play, RotateCcw } from 'lucide-react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  generateLstmCurveData,
  generateRlRewardCurve,
  RL_LOOP_SAMPLES,
} from '../utils/aiModels';
import { RevealSection } from './MotionPrimitives';

export const AiEngineSection: React.FC = () => {
  const prefersReducedMotion = useReducedMotion();
  const fullLstmData = useMemo(() => generateLstmCurveData(), []);
  const rlRewardData = useMemo(() => generateRlRewardCurve(), []);

  const [revealedPoints, setRevealedPoints] = useState<number>(fullLstmData.length);
  const [isDrawing, setIsDrawing] = useState(false);
  const [activeRlIdx, setActiveRlIdx] = useState(0);

  // Self-drawing LSTM curve replay
  useEffect(() => {
    if (!isDrawing) return;
    if (revealedPoints >= fullLstmData.length) {
      setIsDrawing(false);
      return;
    }
    const timer = window.setTimeout(() => {
      setRevealedPoints((n) => Math.min(fullLstmData.length, n + 1));
    }, 95);
    return () => window.clearTimeout(timer);
  }, [isDrawing, revealedPoints, fullLstmData.length]);

  // Cycle RL State -> Action -> Reward step highlight automatically
  useEffect(() => {
    if (prefersReducedMotion) return;
    const timer = window.setInterval(() => {
      setActiveRlIdx((i) => (i + 1) % RL_LOOP_SAMPLES.length);
    }, 3200);
    return () => window.clearInterval(timer);
  }, [prefersReducedMotion]);

  const visibleLstm = fullLstmData.slice(0, revealedPoints);
  const activeSample = RL_LOOP_SAMPLES[activeRlIdx];

  const handleReplayLstm = () => {
    setRevealedPoints(2);
    setIsDrawing(true);
  };

  return (
    <section id="ai-engine" className="py-20 border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <RevealSection>
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
            <div className="max-w-2xl">
              <p className="font-mono text-xs uppercase tracking-widest text-[#22E58B]">
                05 · Hybrid Intelligence Core
              </p>
              <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-slate-100 text-balance">
                Inside the LSTM & Reinforcement Learning Engine
              </h2>
              <p className="mt-2 text-slate-400 text-sm sm:text-base">
                Dual neural architecture combining sequence forecasting with real-time optimal control.
              </p>
            </div>
            <div className="px-3.5 py-2 rounded-lg bg-[#22D3EE]/10 border border-[#22D3EE]/30 text-xs font-mono text-[#22D3EE] shrink-0">
              In-browser physics & Q-policy simulation modeled on NASA / CALCE aging behavior
            </div>
          </div>
        </RevealSection>

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left 7 Cols: LSTM SoH & RUL Forecaster */}
          <RevealSection className="lg:col-span-7">
            <div className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between">
              <div>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg bg-[#22D3EE]/15 border border-[#22D3EE]/35 text-[#22D3EE] flex items-center justify-center">
                      <BrainCircuit className="w-4 h-4" aria-hidden="true" />
                    </div>
                    <div>
                      <h3 className="font-display text-lg font-bold text-slate-100">
                        LSTM Health & RUL Predictor
                      </h3>
                      <p className="text-xs text-slate-400">
                        Actual vs. LSTM Forecasted SoH (%) across 1,000 charge cycles
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleReplayLstm}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-semibold text-slate-200 cursor-pointer whitespace-nowrap"
                  >
                    {isDrawing ? (
                      <>
                        <RotateCcw className="w-3.5 h-3.5 animate-spin" aria-hidden="true" />
                        <span>Drawing...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Animate Forecast Curve</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="mt-5 h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={visibleLstm}>
                      <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                      <XAxis
                        dataKey="cycle"
                        tick={{ fill: '#64748B', fontSize: 11 }}
                        label={{ value: 'Cycles', position: 'insideBottomRight', offset: -4, fill: '#64748B', fontSize: 10 }}
                      />
                      <YAxis domain={[75, 101]} tick={{ fill: '#94A3B8', fontSize: 11 }} unit="%" width={42} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0B101B',
                          borderColor: 'rgba(255,255,255,0.12)',
                          borderRadius: '8px',
                          fontSize: '12px',
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: '11px' }} />
                      <Area
                        type="monotone"
                        dataKey="upperBound"
                        stroke="none"
                        fill="#22D3EE"
                        fillOpacity={0.08}
                        name="Confidence Band"
                        isAnimationActive={false}
                      />
                      <Line
                        type="monotone"
                        dataKey="actualSoh"
                        name="NASA/CALCE Actual SoH (%)"
                        stroke="#94A3B8"
                        strokeWidth={2}
                        dot={false}
                        isAnimationActive={false}
                      />
                      <Line
                        type="monotone"
                        dataKey="predictedSoh"
                        name="LSTM Predicted SoH (%)"
                        stroke="#22E58B"
                        strokeWidth={2.5}
                        dot={false}
                        isAnimationActive={false}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-white/10 grid grid-cols-3 gap-3 text-xs font-mono tabular-nums">
                <div>
                  <span className="text-slate-400">Model Error (RMSE)</span>
                  <div className="text-sm font-bold text-[#22E58B] mt-0.5">0.41% SoH</div>
                </div>
                <div>
                  <span className="text-slate-400">Knee-Point Horizon</span>
                  <div className="text-sm font-bold text-slate-100 mt-0.5">~650 Cycles</div>
                </div>
                <div>
                  <span className="text-slate-400">EoL Threshold</span>
                  <div className="text-sm font-bold text-[#F59E0B] mt-0.5">80.0% SoH</div>
                </div>
              </div>
            </div>
          </RevealSection>

          {/* Right 5 Cols: RL State -> Action -> Reward Loop */}
          <RevealSection delay={0.1} className="lg:col-span-5">
            <div className="glass-panel rounded-xl p-6 h-full flex flex-col justify-between space-y-5">
              <div>
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-lg bg-[#22E58B]/15 border border-[#22E58B]/35 text-[#22E58B] flex items-center justify-center">
                    <Cpu className="w-4 h-4" aria-hidden="true" />
                  </div>
                  <div>
                    <h3 className="font-display text-lg font-bold text-slate-100">
                      Reinforcement Learning Policy Loop
                    </h3>
                    <p className="text-xs text-slate-400">
                      State → Action → Reward adaptive current tuner
                    </p>
                  </div>
                </div>

                {/* Scenario step tabs */}
                <div className="mt-4 flex flex-wrap gap-1.5" role="tablist" aria-label="RL operating states">
                  {RL_LOOP_SAMPLES.map((sample, idx) => (
                    <button
                      key={sample.stepName}
                      type="button"
                      role="tab"
                      aria-selected={idx === activeRlIdx}
                      onClick={() => setActiveRlIdx(idx)}
                      className={`px-2.5 py-1 rounded-md text-xs font-medium cursor-pointer transition-colors whitespace-nowrap ${
                        idx === activeRlIdx
                          ? 'bg-[#22E58B] text-[#070A0F] font-semibold'
                          : 'bg-white/[0.04] text-slate-300 hover:bg-white/[0.08]'
                      }`}
                    >
                      {sample.stepName}
                    </button>
                  ))}
                </div>

                {/* Animated State -> Action -> Reward Flow */}
                <div className="mt-4 grid grid-cols-1 gap-2.5">
                  <motion.div
                    key={`state-${activeRlIdx}`}
                    initial={prefersReducedMotion ? undefined : { opacity: 0.5, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="rounded-lg bg-white/[0.03] border border-white/10 p-3"
                  >
                    <div className="text-[11px] font-mono uppercase tracking-wider text-[#22D3EE]">
                      1. Observed State (s_t)
                    </div>
                    <div className="text-xs font-mono text-slate-100 mt-1 tabular-nums">
                      {activeSample.state}
                    </div>
                  </motion.div>

                  <div className="flex justify-center text-slate-500" aria-hidden="true">
                    <ArrowRight className="w-4 h-4 rotate-90" />
                  </div>

                  <motion.div
                    key={`action-${activeRlIdx}`}
                    initial={prefersReducedMotion ? undefined : { opacity: 0.5, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.06 }}
                    className="rounded-lg bg-[#22E58B]/10 border border-[#22E58B]/30 p-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono uppercase tracking-wider text-[#22E58B]">
                        2. RL Action (a_t)
                      </span>
                      <span className="text-xs font-mono font-bold text-[#22E58B]">
                        Reward {activeSample.reward}
                      </span>
                    </div>
                    <div className="text-xs font-mono text-slate-100 mt-1">
                      {activeSample.action}
                    </div>
                    <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                      {activeSample.rationale}
                    </p>
                  </motion.div>
                </div>
              </div>

              {/* Episode Reward Convergence Chart */}
              <div>
                <p className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
                  Q-Policy Reward Convergence (40 Episodes)
                </p>
                <div className="h-32 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={rlRewardData}>
                      <CartesianGrid stroke="rgba(148,163,184,0.1)" strokeDasharray="3 3" />
                      <XAxis dataKey="episode" tick={{ fill: '#64748B', fontSize: 10 }} />
                      <YAxis tick={{ fill: '#22E58B', fontSize: 10 }} width={32} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#0B101B',
                          borderColor: 'rgba(255,255,255,0.12)',
                          borderRadius: '8px',
                          fontSize: '12px',
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="reward"
                        name="Episode Reward"
                        stroke="#22E58B"
                        strokeWidth={2}
                        dot={false}
                        isAnimationActive={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </RevealSection>
        </div>
      </div>
    </section>
  );
};
